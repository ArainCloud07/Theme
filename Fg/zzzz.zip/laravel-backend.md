# SKA HOSTING - Laravel Backend Integration

This guide provides the exact Laravel code needed to integrate the Redeem Codes, Version Changer, Plugin Installer, and Mod Installer into your Pterodactyl panel.

## 1. API Routes (routes/api/client.php)

Open your `routes/api/client.php` file and add the following routes inside the appropriate middleware group (usually `auth:api` or similar client authentication middleware):

```php
use App\Http\Controllers\Api\Client\RedeemController;
use App\Http\Controllers\Api\Client\SoftwareController;

Route::group(['middleware' => ['auth:api']], function () {
    // Redeem Codes
    Route::post('/store/redeem', [RedeemController::class, 'claim']);

    // Software Management (Versions, Plugins, Mods)
    Route::get('/servers/{server}/versions', [SoftwareController::class, 'getVersions']);
    Route::post('/servers/{server}/version', [SoftwareController::class, 'updateVersion']);
    
    Route::get('/servers/{server}/plugins', [SoftwareController::class, 'getPlugins']);
    Route::post('/servers/{server}/plugins/install', [SoftwareController::class, 'installPlugin']);
    
    Route::get('/servers/{server}/mods', [SoftwareController::class, 'getMods']);
    Route::post('/servers/{server}/mods/install', [SoftwareController::class, 'installMod']);
});
```

## 2. Redeem Controller (app/Http/Controllers/Api/Client/RedeemController.php)

Create or update the `RedeemController.php` file:

```php
<?php

namespace App\Http\Controllers\Api\Client;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RedeemController extends Controller
{
    public function claim(Request $request)
    {
        $request->validate([
            'code' => 'required|string',
        ]);

        $codeStr = strtoupper($request->input('code'));
        $user = $request->user();

        // Find the code
        $code = DB::table('redeem_codes')->where('code', $codeStr)->first();

        if (!$code) {
            return response()->json(['success' => false, 'message' => 'Invalid code.'], 404);
        }

        // Check uses
        if ($code->max_uses > 0 && $code->current_uses >= $code->max_uses) {
            return response()->json(['success' => false, 'message' => 'Code has reached max uses.'], 400);
        }

        // Check expiration
        if ($code->expires_at && now()->greaterThan($code->expires_at)) {
            return response()->json(['success' => false, 'message' => 'Code has expired.'], 400);
        }

        // Check if user already claimed
        $alreadyClaimed = DB::table('user_redeems')
            ->where('user_id', $user->id)
            ->where('code_id', $code->id)
            ->exists();

        if ($alreadyClaimed) {
            return response()->json(['success' => false, 'message' => 'You have already redeemed this code.'], 400);
        }

        // Process claim
        DB::beginTransaction();
        try {
            // Update user balance (assuming 'coins' column exists on users table)
            DB::table('users')->where('id', $user->id)->increment('coins', $code->reward_coins);

            // Increment code uses
            DB::table('redeem_codes')->where('id', $code->id)->increment('current_uses');

            // Log the redemption
            DB::table('user_redeems')->insert([
                'user_id' => $user->id,
                'code_id' => $code->id,
                'created_at' => now(),
            ]);

            DB::commit();

            // Fetch updated user to return new balance
            $updatedUser = DB::table('users')->where('id', $user->id)->first();

            return response()->json([
                'success' => true,
                'reward' => $code->reward_coins,
                'new_balance' => $updatedUser->coins,
                'message' => "Successfully redeemed! Added {$code->reward_coins} coins."
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['success' => false, 'message' => 'An error occurred while redeeming.'], 500);
        }
    }
}
```

## 3. Software Controller (app/Http/Controllers/Api/Client/SoftwareController.php)

Create the `SoftwareController.php` file to handle fetching and installing software:

```php
<?php

namespace App\Http\Controllers\Api\Client;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Pterodactyl\Models\Server;

class SoftwareController extends Controller
{
    // --- VERSIONS ---
    public function getVersions(Request $request, Server $server)
    {
        // Example: Fetching PaperMC versions
        // You can adjust this based on the server's egg type
        try {
            $response = Http::get('https://api.papermc.io/v2/projects/paper');
            if ($response->successful()) {
                $versions = $response->json()['versions'] ?? [];
                // Return the latest 20 versions reversed
                $latestVersions = array_slice(array_reverse($versions), 0, 20);
                return response()->json($latestVersions);
            }
            return response()->json([], 500);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Failed to fetch versions'], 500);
        }
    }

    public function updateVersion(Request $request, Server $server)
    {
        $request->validate([
            'version' => 'required|string',
        ]);

        // Logic to update the server's startup variable (e.g., MINECRAFT_VERSION)
        // and trigger a reinstall via Wings.
        // This requires interacting with Pterodactyl's internal repositories.
        
        // Example (Conceptual):
        // $variable = $server->variables()->where('env_variable', 'MINECRAFT_VERSION')->first();
        // $variable->server_value = $request->input('version');
        // $variable->save();
        // 
        // // Trigger reinstall
        // $this->reinstallServerService->handle($server);

        return response()->json(['success' => true, 'message' => 'Version updated and reinstall triggered.']);
    }

    // --- PLUGINS ---
    public function getPlugins(Request $request, Server $server)
    {
        // Fetch from Spiget API
        try {
            $response = Http::get('https://api.spiget.org/v2/resources/free?size=20&sort=-downloads');
            if ($response->successful()) {
                $plugins = collect($response->json())->map(function ($p) {
                    return [
                        'id' => $p['id'],
                        'name' => $p['name'],
                        'tag' => $p['tag'],
                        'downloads' => $p['downloads']
                    ];
                });
                return response()->json($plugins);
            }
            return response()->json([], 500);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Failed to fetch plugins'], 500);
        }
    }

    public function installPlugin(Request $request, Server $server)
    {
        $request->validate([
            'plugin_id' => 'required|numeric',
        ]);

        // Logic to download the plugin via Wings File Management API
        // You will need to construct a download URL from Spiget and send a 
        // "pull" request to the Wings daemon for this server.

        return response()->json(['success' => true, 'message' => 'Plugin installation started.']);
    }

    // --- MODS ---
    public function getMods(Request $request, Server $server)
    {
        // Fetch from Modrinth API
        try {
            $response = Http::get('https://api.modrinth.com/v2/search?limit=20&facets=[["categories:fabric"]]');
            if ($response->successful()) {
                $mods = collect($response->json()['hits'])->map(function ($m) {
                    return [
                        'id' => $m['project_id'],
                        'title' => $m['title'],
                        'description' => $m['description'],
                        'downloads' => $m['downloads']
                    ];
                });
                return response()->json($mods);
            }
            return response()->json([], 500);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Failed to fetch mods'], 500);
        }
    }

    public function installMod(Request $request, Server $server)
    {
        $request->validate([
            'mod_id' => 'required|string',
        ]);

        // Logic to download the mod via Wings File Management API
        // You will need to get the specific version file URL from Modrinth
        // and send a "pull" request to the Wings daemon.

        return response()->json(['success' => true, 'message' => 'Mod installation started.']);
    }
}
```

## 4. Database Requirements

Ensure your database has the following tables/columns for the Redeem system:

1. `users` table needs a `coins` column (integer).
2. `redeem_codes` table:
   - `id`
   - `code` (string, unique)
   - `reward_coins` (integer)
   - `max_uses` (integer, 0 for unlimited)
   - `current_uses` (integer)
   - `expires_at` (timestamp, nullable)
3. `user_redeems` table:
   - `id`
   - `user_id` (foreign key to users)
   - `code_id` (foreign key to redeem_codes)
   - `created_at` (timestamp)
