import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Serve the install script
  app.get("/install.sh", (req, res) => {
    const scriptPath = path.resolve(process.cwd(), "install.sh");
    console.log(`Serving install script from: ${scriptPath}`);
    if (fs.existsSync(scriptPath)) {
      res.setHeader("Content-Type", "text/plain"); // Use text/plain for curl
      res.sendFile(scriptPath);
    } else {
      res.status(404).send("Install script not found");
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
