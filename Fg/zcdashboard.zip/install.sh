#!/bin/bash

# VP THEME - Pterodactyl Theme Installer
# Repository: https://github.com/sdgamer8263-sketch/vp

echo "Starting VP Theme Installation for Pterodactyl..."

# Check for root
if [ "$EUID" -ne 0 ]; then
  echo "Please run as root"
  exit
fi

# Check for Pterodactyl installation
if [ ! -d "/var/www/pterodactyl" ]; then
  echo "Pterodactyl installation not found in /var/www/pterodactyl"
  echo "Please make sure Pterodactyl is installed correctly."
  exit
fi

# Install Node.js if missing
if ! command -v node &> /dev/null; then
    echo "Installing Node.js..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt install -y nodejs
fi

# Install Yarn if missing
if ! command -v yarn &> /dev/null; then
    echo "Installing Yarn..."
    npm install -g yarn
fi

cd /var/www/pterodactyl

# Maintenance mode
echo "Entering maintenance mode..."
php artisan down

# Download theme files
echo "Downloading theme files..."
rm -rf /tmp/vp-theme
git clone https://github.com/sdgamer8263-sketch/vp /tmp/vp-theme
cp -r /tmp/vp-theme/* /var/www/pterodactyl/
rm -rf /tmp/vp-theme

# Apply fixes for Vite/PostCSS ESM compatibility
echo "Applying Vite/PostCSS fixes..."
cd /var/www/pterodactyl
# Safely remove "type": "module" using Node.js to avoid JSON syntax errors
node -e 'const fs = require("fs"); const pkg = JSON.parse(fs.readFileSync("package.json", "utf8")); delete pkg.type; fs.writeFileSync("package.json", JSON.stringify(pkg, null, 2));'

# Ensure vite.config uses .mts extension for ESM support in CJS project
if [ -f "vite.config.ts" ]; then
    mv vite.config.ts vite.config.mts
fi

# Fix tsconfig.json JSX property for Vite compatibility (handles comments better than JSON.parse)
fix_tsconfig() {
    if [ -f "$1" ]; then
        echo "Fixing $1 JSX property..."
        # Replace any "jsx": "..." with "jsx": "react-jsx"
        sed -i 's/"jsx": *"[^"]*"/"jsx": "react-jsx"/g' "$1"
        # If jsx property is missing, add it to compilerOptions
        if ! grep -q '"jsx"' "$1"; then
            sed -i '/"compilerOptions": *{/a \    "jsx": "react-jsx",' "$1"
        fi
    fi
}

fix_tsconfig "tsconfig.json"
fix_tsconfig "resources/scripts/tsconfig.json"

# Remove ALL PostCSS config files recursively to prevent conflicts
# Tailwind 4 handles CSS processing via its Vite plugin
find . -name "postcss.config.*" -delete

# Remove yarn.lock to prevent dependency conflicts
rm -f yarn.lock

# Install dependencies and build
echo "Installing dependencies and building theme..."
export NODE_OPTIONS=--max_old_space_size=4096
yarn install
yarn build

# Clear cache
echo "Clearing cache..."
php artisan view:clear
php artisan config:clear

# Exit maintenance mode
echo "Exiting maintenance mode..."
php artisan up

echo "Installation completed successfully!"
echo "VP Theme has been applied to your Pterodactyl panel."
