import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Mock Data matching the requested schema
  let mockUser = {
    id: 1,
    username: "Admin",
    email: "admin@skahosting.com",
    role: "admin", // Added role for Step 6
    root_admin: true, // Added for Step 3
    coins: 5,
    afk_time: 0,
    limits: {
      servers: 1,
      ram: 2048, // 2GB
      cpu: 200,
      disk: 12288, // 12GB
    }
  };

  let mockServers = [
    {
      id: 1,
      name: "Minecraft Survival",
      bg_image: "https://picsum.photos/seed/mc/800/400",
      icon_image: "https://picsum.photos/seed/mcicon/100/100",
      custom_icon_image: null,
      approval_status: "approved",
      auto_suspended: false,
      auto_backup: true,
      software_type: "java",
      resources: { ram: 1024, cpu: 100, disk: 5120 }
    }
  ];

  let mockMappers = {
    nodes: [
      { id: 1, custom_name: "Premium Node 1", actual_id: "node_01" },
      { id: 2, custom_name: "Budget Node 2", actual_id: "node_02" }
    ],
    eggs: [
      { id: 1, custom_name: "Paper MC", actual_id: "egg_paper_1" },
      { id: 2, custom_name: "Bedrock Dedicated", actual_id: "egg_bedrock_1" }
    ]
  };

  let mockRedeemCodes = [
    { id: 1, code: "WELCOME10", reward_coins: 10, max_uses: 100, current_uses: 5, expires_at: null },
    { id: 2, code: "SKA2024", reward_coins: 50, max_uses: 10, current_uses: 0, expires_at: "2024-12-31T23:59:59Z" }
  ];

  let mockExtensions = [
    { id: 1, name: "Blueprint Core", version: "1.0.0", description: "The core extension for Blueprint." },
    { id: 2, name: "Advanced Backups", version: "2.1.0", description: "Enhanced backup management." }
  ];

  let mockTickets = [
    { id: 1, userId: 1, subject: "Server not starting", status: "open", messages: [{ sender: "user", text: "Help me", timestamp: new Date().toISOString() }] }
  ];

  let mockUserRedeems: { userId: number, codeId: number }[] = [];

  let mockAdminSettings = {
    admin_theme: "dark",
    show_node_ids: true,
    payment_methods: ["PayPal", "Stripe", "Crypto"],
    discord_bot: {
      token: "MTE...",
      guild_id: "1234567890",
      log_channel_id: "0987654321",
      notify_on_create: true,
      notify_on_suspend: false
    },
    default_user_specs: { ram: 2048, cpu: 200, disk: 10240, servers: 1, coins: 10 },
    upgrade_pricing: { ram: 5, cpu: 10, disk: 2, servers: 50 },
    afk_coin_amount: 0.1,
    afk_time_interval: 60,
    global_dashboard_bg: "https://picsum.photos/seed/global/1920/1080",
    automation: {
      db_backups: { enabled: true, frequency: "daily", retention: 7 },
      node_backups: { enabled: false, frequency: "weekly", retention: 4 }
    }
  };

  const mockSettings = {
    discord_link: "https://discord.gg/skahosting",
    dashboard_name: "SKA HOSTING",
    resource_upgrade_toggle: true,
    coin_prices: { "100": 1.00, "500": 4.50 },
    afk_coin_rate: 0.1
  };

  // API routes
  app.get("/api/user", (req, res) => res.json(mockUser));
  app.get("/api/servers", (req, res) => res.json(mockServers));
  app.get("/api/settings", (req, res) => res.json(mockSettings));
  app.get("/api/admin/mappers", (req, res) => res.json(mockMappers));
  app.get("/api/deploy/nodes", (req, res) => res.json(mockMappers.nodes));
  app.get("/api/deploy/eggs", (req, res) => res.json(mockMappers.eggs));
  app.get("/api/admin/settings", (req, res) => res.json(mockAdminSettings));
  app.get("/api/admin/redeem-codes", (req, res) => res.json(mockRedeemCodes));
  app.get("/api/extensions", (req, res) => res.json(mockExtensions));
  
  // Tickets
  app.get("/api/tickets", (req, res) => {
    // If admin, return all. If user, return only theirs.
    // For mock, we just return all if root_admin, else filter by user id
    if (mockUser.root_admin) {
      res.json(mockTickets);
    } else {
      res.json(mockTickets.filter(t => t.userId === mockUser.id));
    }
  });

  app.post("/api/tickets", (req, res) => {
    const newTicket = {
      id: mockTickets.length + 1,
      userId: mockUser.id,
      subject: req.body.subject,
      status: "open",
      messages: [{ sender: "user", text: req.body.message, timestamp: new Date().toISOString() }]
    };
    mockTickets.push(newTicket);
    res.json(newTicket);
  });

  app.post("/api/tickets/:id/reply", (req, res) => {
    const ticket = mockTickets.find(t => t.id === parseInt(req.params.id));
    if (ticket) {
      ticket.messages.push({
        sender: mockUser.root_admin ? "admin" : "user",
        text: req.body.message,
        timestamp: new Date().toISOString()
      });
      res.json(ticket);
    } else {
      res.status(404).json({ error: "Ticket not found" });
    }
  });

  // Server Power Management
  app.post("/api/client/servers/:id/power", (req, res) => {
    const server = mockServers.find(s => s.id === parseInt(req.params.id));
    if (server) {
      const action = req.body.signal; // start, stop, restart
      console.log(`[WINGS MOCK] Sending power signal ${action} to server ${server.id}`);
      res.json({ success: true, status: action === 'stop' ? 'offline' : 'running' });
    } else {
      res.status(404).json({ error: "Server not found" });
    }
  });

  // Admin Redeem Codes
  app.post("/api/admin/redeem-codes", (req, res) => {
    const newCode = { ...req.body, id: Date.now(), current_uses: 0 };
    mockRedeemCodes.push(newCode);
    res.json(newCode);
  });

  app.delete("/api/admin/redeem-codes/:id", (req, res) => {
    mockRedeemCodes = mockRedeemCodes.filter(c => c.id !== parseInt(req.params.id));
    res.json({ success: true });
  });

  // User Redeem
  app.post("/api/economy/redeem", (req, res) => {
    const { code } = req.body;
    const redeemCode = mockRedeemCodes.find(c => c.code === code.toUpperCase());

    if (!redeemCode) return res.status(404).json({ success: false, message: "Invalid code." });
    if (redeemCode.current_uses >= redeemCode.max_uses) return res.status(400).json({ success: false, message: "Code has reached max uses." });
    if (redeemCode.expires_at && new Date(redeemCode.expires_at) < new Date()) return res.status(400).json({ success: false, message: "Code has expired." });
    
    const alreadyRedeemed = mockUserRedeems.some(r => r.userId === mockUser.id && r.codeId === redeemCode.id);
    if (alreadyRedeemed) return res.status(400).json({ success: false, message: "You have already redeemed this code." });

    // Success
    mockUser.coins += redeemCode.reward_coins;
    redeemCode.current_uses += 1;
    mockUserRedeems.push({ userId: mockUser.id, codeId: redeemCode.id });

    res.json({ success: true, reward: redeemCode.reward_coins, new_balance: mockUser.coins, message: `Successfully redeemed! Added ${redeemCode.reward_coins} coins.`, user: mockUser });
  });

  // Admin Mapper Updates
  app.post("/api/admin/mappers/:type", (req, res) => {
    const { type } = req.params;
    const item = req.body;
    if (type === 'nodes' || type === 'eggs') {
      const newItem = { ...item, id: Date.now() };
      mockMappers[type].push(newItem);
      res.json(mockMappers[type]);
    } else {
      res.status(400).send("Invalid type");
    }
  });

  app.delete("/api/admin/mappers/:type/:id", (req, res) => {
    const { type, id } = req.params;
    const itemId = parseInt(id);
    if (type === 'nodes' || type === 'eggs') {
      mockMappers[type] = mockMappers[type].filter(i => i.id !== itemId);
      res.json(mockMappers[type]);
    } else {
      res.status(400).send("Invalid type");
    }
  });

  // Server Visuals Update
  app.post("/api/servers/:id/visuals", (req, res) => {
    const { id } = req.params;
    const { bg_image, custom_icon_image } = req.body;
    const server = mockServers.find(s => s.id === parseInt(id));
    if (server) {
      if (bg_image !== undefined) server.bg_image = bg_image;
      if (custom_icon_image !== undefined) server.custom_icon_image = custom_icon_image;
      res.json(server);
    } else {
      res.status(404).send("Server not found");
    }
  });

  // Admin Settings Update
  app.post("/api/admin/settings", (req, res) => {
    mockAdminSettings = { ...mockAdminSettings, ...req.body };
    if (req.body.dashboard_name) mockSettings.dashboard_name = req.body.dashboard_name;
    if (req.body.discord_link) mockSettings.discord_link = req.body.discord_link;
    if (req.body.resource_upgrade_toggle !== undefined) mockSettings.resource_upgrade_toggle = req.body.resource_upgrade_toggle;
    res.json(mockAdminSettings);
  });

  app.post("/api/admin/settings/payments", (req, res) => {
    const { method, action } = req.body;
    if (action === 'add') {
      if (!mockAdminSettings.payment_methods.includes(method)) {
        mockAdminSettings.payment_methods.push(method);
      }
    } else if (action === 'remove') {
      mockAdminSettings.payment_methods = mockAdminSettings.payment_methods.filter(m => m !== method);
    }
    res.json(mockAdminSettings.payment_methods);
  });

  // Server Suspension
  app.post("/api/admin/servers/suspend/:id", (req, res) => {
    const server = mockServers.find(s => s.id === parseInt(req.params.id));
    if (server) {
      server.auto_suspended = !server.auto_suspended;
      
      if (server.auto_suspended) {
        sendDiscordNotification(`🛑 Server suspended: **${server.name}**`, 'suspend');
      }
      
      res.json(server);
    } else {
      res.status(404).send("Not found");
    }
  });

  // Step 2: Economy - AFK Coin Generation
  app.post("/api/economy/afk", (req, res) => {
    mockUser.afk_time += 1;
    mockUser.coins += mockSettings.afk_coin_rate;
    res.json({ coins: mockUser.coins, afk_time: mockUser.afk_time });
  });

  // Step 2: Economy - Resource Upgrade
  app.post("/api/economy/upgrade", (req, res) => {
    const { type, amount, cost } = req.body;
    if (mockUser.coins >= cost) {
      mockUser.coins -= cost;
      if (type === 'ram') mockUser.limits.ram += amount;
      if (type === 'cpu') mockUser.limits.cpu += amount;
      if (type === 'disk') mockUser.limits.disk += amount;
      if (type === 'servers') mockUser.limits.servers += amount;
      res.json({ success: true, user: mockUser });
    } else {
      res.status(400).json({ success: false, message: "Insufficient coins" });
    }
  });

  // Mock Discord Notification Service
  const sendDiscordNotification = (message: string, type: 'create' | 'suspend') => {
    if (!mockAdminSettings.discord_bot.token || !mockAdminSettings.discord_bot.log_channel_id) return;
    
    if (type === 'create' && !mockAdminSettings.discord_bot.notify_on_create) return;
    if (type === 'suspend' && !mockAdminSettings.discord_bot.notify_on_suspend) return;

    console.log(`[DISCORD BOT] Sending to channel ${mockAdminSettings.discord_bot.log_channel_id}: ${message}`);
  };

  app.get("/api/client/servers/:id/versions", async (req, res) => {
    // Mock PaperMC versions
    try {
      const response = await fetch("https://api.papermc.io/v2/projects/paper");
      const data = await response.json();
      const versions = data.versions.reverse().slice(0, 20); // Get latest 20 versions
      res.json(versions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch versions" });
    }
  });

  app.get("/api/client/servers/:id/plugins", async (req, res) => {
    // Mock Spiget plugins
    try {
      const response = await fetch("https://api.spiget.org/v2/resources/free?size=20&sort=-downloads");
      const data = await response.json();
      const plugins = data.map((p: any) => ({
        id: p.id,
        name: p.name,
        tag: p.tag,
        downloads: p.downloads
      }));
      res.json(plugins);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch plugins" });
    }
  });

  app.get("/api/client/servers/:id/mods", async (req, res) => {
    // Mock Modrinth mods
    try {
      const response = await fetch("https://api.modrinth.com/v2/search?limit=20&facets=[[%22categories:fabric%22]]");
      const data = await response.json();
      const mods = data.hits.map((m: any) => ({
        id: m.project_id,
        title: m.title,
        description: m.description,
        downloads: m.downloads
      }));
      res.json(mods);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch mods" });
    }
  });

  app.post("/api/client/servers/:id/version", (req, res) => {
    const server = mockServers.find(s => s.id === parseInt(req.params.id));
    if (server) {
      console.log(`[WINGS MOCK] Updating server ${server.id} to version ${req.body.version} and triggering reinstall`);
      res.json({ success: true });
    } else {
      res.status(404).json({ error: "Server not found" });
    }
  });

  app.post("/api/client/servers/:id/plugins/install", (req, res) => {
    const server = mockServers.find(s => s.id === parseInt(req.params.id));
    if (server) {
      console.log(`[WINGS MOCK] Downloading plugin ${req.body.plugin_id} to /home/container/plugins on server ${server.id}`);
      setTimeout(() => {
        res.json({ success: true });
      }, 1500);
    } else {
      res.status(404).json({ error: "Server not found" });
    }
  });

  app.post("/api/client/servers/:id/mods/install", (req, res) => {
    const server = mockServers.find(s => s.id === parseInt(req.params.id));
    if (server) {
      console.log(`[WINGS MOCK] Downloading mod ${req.body.mod_id} to /home/container/mods on server ${server.id}`);
      setTimeout(() => {
        res.json({ success: true });
      }, 1500);
    } else {
      res.status(404).json({ error: "Server not found" });
    }
  });

  // Step 2: Server Creation Queue
  app.post("/api/servers/create", (req, res) => {
    const newServer = {
      id: mockServers.length + 1,
      name: req.body.name,
      bg_image: "https://picsum.photos/seed/new/800/400",
      icon_image: "https://picsum.photos/seed/newicon/100/100",
      custom_icon_image: null,
      approval_status: "pending",
      auto_suspended: false,
      auto_backup: false,
      software_type: req.body.software_type || "java",
      resources: req.body.resources
    };
    mockServers.push(newServer);
    
    // Trigger Discord Notification
    sendDiscordNotification(`🚀 New server requested: **${newServer.name}** (${newServer.software_type})`, 'create');
    
    res.json(newServer);
  });

  // Step 2: Admin Approval
  app.post("/api/admin/servers/approve/:id", (req, res) => {
    const server = mockServers.find(s => s.id === parseInt(req.params.id));
    if (server) {
      server.approval_status = "approved";
      res.json(server);
    } else {
      res.status(404).json({ message: "Server not found" });
    }
  });

  // Step 2: Tools - Backup
  app.post("/api/tools/backup/:id", (req, res) => {
    res.json({ success: true, message: "Backup initiated for server " + req.params.id });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`SKA HOSTING Server running on http://localhost:${PORT}`);
  });
}

startServer();
