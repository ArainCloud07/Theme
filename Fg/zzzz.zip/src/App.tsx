import React, { useEffect, useState, createContext, useContext } from 'react';
import { 
  LayoutDashboard, 
  Server, 
  Coins, 
  Settings, 
  ShieldCheck, 
  Database, 
  Cpu, 
  HardDrive, 
  Activity,
  ExternalLink,
  MessageSquare,
  LogOut,
  Plus,
  Globe,
  Snowflake,
  User,
  Lock,
  Mail,
  Loader2,
  ArrowRight,
  Eye,
  EyeOff,
  Upload,
  Users,
  Scissors,
  Link as LinkIcon,
  FileText,
  AlertTriangle,
  Terminal,
  Clock,
  Zap,
  UserMinus,
  UserX,
  Share2,
  X,
  Puzzle,
  ChevronDown
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { BrowserRouter as Router, Routes, Route, Navigate, Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import axios from 'axios';
import { Toaster, toast } from 'sonner';

// --- Types & Context ---

interface UserData {
  username: string;
  coins: number;
  afk_time: number;
  role: 'admin' | 'user'; // Added role for Step 6
  root_admin: boolean; // Added for Step 3
  limits: {
    servers: number;
    ram: number;
    cpu: number;
    disk: number;
  };
}

interface ServerData {
  id: number;
  name: string;
  bg_image: string;
  icon_image: string;
  custom_icon_image?: string;
  approval_status: 'pending' | 'approved' | 'rejected';
  auto_suspended: boolean;
  auto_backup: boolean;
  software_type: 'java' | 'bedrock' | 'pocketmine';
  resources: { ram: number; cpu: number; disk: number };
}

interface SettingsData {
  discord_link: string;
  dashboard_name: string;
  resource_upgrade_toggle: boolean;
  coin_prices: Record<string, number>;
  afk_coin_rate: number;
}

interface AdminSettings {
  admin_theme: 'light' | 'dark';
  show_node_ids: boolean;
  payment_methods: string[];
  discord_bot: {
    token: string;
    guild_id: string;
    log_channel_id: string;
    notify_on_create: boolean;
    notify_on_suspend: boolean;
  };
  default_user_specs: { ram: number; cpu: number; disk: number; servers: number; coins: number };
  upgrade_pricing: { ram: number; cpu: number; disk: number; servers: number };
  automation: {
    db_backups: { enabled: boolean; frequency: string; retention: number };
    node_backups: { enabled: boolean; frequency: string; retention: number };
  };
}

interface MapperItem {
  id: number;
  custom_name: string;
  actual_id: string;
}

interface MapperData {
  nodes: MapperItem[];
  eggs: MapperItem[];
}

const AuthContext = createContext<{
  user: UserData | null;
  setUser: React.Dispatch<React.SetStateAction<UserData | null>>;
  settings: SettingsData | null;
  setSettings: React.Dispatch<React.SetStateAction<SettingsData | null>>;
  adminSettings: AdminSettings | null;
  setAdminSettings: React.Dispatch<React.SetStateAction<AdminSettings | null>>;
  loading: boolean;
  snowEnabled: boolean;
  setSnowEnabled: React.Dispatch<React.SetStateAction<boolean>>;
} | null>(null);

// --- Components ---

function Loader() {
  return (
    <div className="fixed inset-0 bg-[#050505] z-[100] flex flex-col items-center justify-center gap-6">
      <div className="relative">
        <div className="w-24 h-24 border-4 border-white/5 rounded-full" />
        <div className="w-24 h-24 border-4 border-orange-500 border-t-transparent rounded-full animate-spin absolute inset-0" />
        <div className="absolute inset-0 flex items-center justify-center font-black text-2xl italic tracking-tighter">S</div>
      </div>
      <div className="flex flex-col items-center gap-2">
        <p className="text-sm font-black tracking-widest uppercase animate-pulse">SKA HOSTING</p>
        <p className="text-[10px] text-white/30 font-mono">INITIALIZING CORE SYSTEMS...</p>
      </div>
    </div>
  );
}

function Snowflakes({ enabled }: { enabled: boolean }) {
  if (!enabled) return null;
  return (
    <div className="fixed inset-0 pointer-events-none z-[60] overflow-hidden">
      {[...Array(50)].map((_, i) => (
        <motion.div
          key={i}
          initial={{ 
            top: -20, 
            left: `${Math.random() * 100}%`,
            opacity: Math.random() * 0.5 + 0.2,
            scale: Math.random() * 0.5 + 0.5
          }}
          animate={{ 
            top: '110%',
            left: `${(Math.random() - 0.5) * 10 + (i * 2)}%`,
            rotate: 360
          }}
          transition={{ 
            duration: Math.random() * 10 + 10, 
            repeat: Infinity, 
            ease: "linear",
            delay: Math.random() * 20
          }}
          className="absolute text-white/20"
        >
          <Snowflake size={Math.random() * 10 + 5} />
        </motion.div>
      ))}
    </div>
  );
}

function LanguageSwitcher() {
  const { i18n } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const languages = [
    { code: 'en', name: 'English' },
    { code: 'es', name: 'Español' },
    { code: 'hi', name: 'हिन्दी' },
    { code: 'bn', name: 'বাংলা' },
    { code: 'fr', name: 'Français' }
  ];

  const currentLang = languages.find(l => l.code === i18n.language) || languages[0];

  return (
    <div className="relative">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-1.5 bg-white/5 hover:bg-white/10 rounded-lg transition-colors border border-white/10"
      >
        <Globe size={16} className="text-white/50" />
        <span className="text-xs font-bold uppercase tracking-widest">{currentLang.code}</span>
      </button>
      
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="absolute right-0 mt-2 w-48 bg-neutral-900 border border-white/10 rounded-xl shadow-2xl z-50 p-2 grid grid-cols-1 gap-1 max-h-64 overflow-y-auto custom-scrollbar"
          >
            {languages.map(lang => (
              <button 
                key={lang.code}
                onClick={() => {
                  i18n.changeLanguage(lang.code);
                  setIsOpen(false);
                }}
                className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium transition-colors flex items-center justify-between group ${
                  i18n.language === lang.code ? 'bg-orange-500 text-black' : 'hover:bg-white/5'
                }`}
              >
                {lang.name}
                <span className={`text-[10px] uppercase ${i18n.language === lang.code ? 'text-black/50' : 'text-white/20 group-hover:text-orange-500'}`}>{lang.code}</span>
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Footer() {
  return (
    <footer className="mt-auto py-8 px-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-4 text-[10px] font-bold tracking-[0.2em] uppercase text-white/20">
      <div className="flex items-center gap-4">
        <span>&copy; 2026 SKA HOSTING</span>
        <span className="w-1 h-1 bg-white/10 rounded-full" />
        <span className="text-orange-500/50">CREDIT BY- SDGAMER, SKA HOST</span>
      </div>
      <div className="flex items-center gap-6">
        <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
        <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
        <a href="#" className="hover:text-white transition-colors">Status</a>
      </div>
    </footer>
  );
}

// --- Auth Pages ---

function LoginPage() {
  const { settings } = useContext(AuthContext)!;
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      navigate('/dashboard');
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-neutral-900 flex items-center justify-center p-6 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_50%,rgba(249,115,22,0.05),transparent_50%)]" />
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md relative z-10"
      >
        <div className="bg-neutral-900 border border-white/10 rounded-[2.5rem] p-10 shadow-2xl">
          <div className="flex flex-col items-center gap-4 mb-10">
            <div className="w-16 h-16 bg-orange-500 rounded-2xl flex items-center justify-center font-black text-3xl text-black italic shadow-2xl shadow-orange-500/20">S</div>
            <div className="text-center">
              <h1 className="text-3xl font-black tracking-tighter italic uppercase text-neutral-50">{settings?.dashboard_name || 'SKA HOSTING'}</h1>
              <p className="text-neutral-400 text-sm font-medium mt-1">{t('login.welcome')}</p>
            </div>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-neutral-500 ml-4">Email Address</label>
              <div className="relative group">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-500 group-focus-within:text-orange-500 transition-colors" size={18} />
                <input 
                  type="email" 
                  required
                  placeholder="admin@skahosting.com"
                  className="w-full bg-neutral-800/50 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-sm focus:border-orange-500/50 focus:bg-white/[0.07] outline-none transition-all text-neutral-50"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-neutral-500 ml-4">Password</label>
              <div className="relative group">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-500 group-focus-within:text-orange-500 transition-colors" size={18} />
                <input 
                  type="password" 
                  required
                  placeholder="••••••••"
                  className="w-full bg-neutral-800/50 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-sm focus:border-orange-500/50 focus:bg-white/[0.07] outline-none transition-all text-neutral-50"
                />
              </div>
            </div>

            <button 
              disabled={loading}
              className="w-full bg-white text-black py-4 rounded-2xl font-black uppercase tracking-[0.2em] text-xs hover:bg-orange-500 transition-all flex items-center justify-center gap-2 group disabled:opacity-50"
            >
              {loading ? <Loader2 className="animate-spin" size={18} /> : (
                <>
                  Access Dashboard
                  <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </button>
          </form>

          <div className="mt-10 pt-8 border-t border-white/5 text-center">
            <p className="text-xs text-neutral-400">
              New to SKA? <Link to="/register" className="text-orange-500 font-bold hover:underline">Create an account</Link>
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

function RegisterPage() {
  const { settings } = useContext(AuthContext)!;
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      navigate('/dashboard');
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-neutral-900 flex items-center justify-center p-6 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_50%,rgba(249,115,22,0.05),transparent_50%)]" />
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md relative z-10"
      >
        <div className="bg-neutral-900 border border-white/10 rounded-[2.5rem] p-10 shadow-2xl">
          <div className="flex flex-col items-center gap-4 mb-10">
            <div className="w-16 h-16 bg-orange-500 rounded-2xl flex items-center justify-center font-black text-3xl text-black italic shadow-2xl shadow-orange-500/20">S</div>
            <div className="text-center">
              <h1 className="text-3xl font-black tracking-tighter italic uppercase text-neutral-50">{settings?.dashboard_name || 'JOIN SKA'}</h1>
              <p className="text-neutral-400 text-sm font-medium mt-1">{t('register.start')}</p>
            </div>
          </div>

          <form onSubmit={handleRegister} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-neutral-500 ml-4">Username</label>
              <div className="relative group">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-500 group-focus-within:text-orange-500 transition-colors" size={18} />
                <input 
                  type="text" 
                  required
                  placeholder="SkaUser"
                  className="w-full bg-neutral-800/50 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-sm focus:border-orange-500/50 focus:bg-white/[0.07] outline-none transition-all text-neutral-50"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-neutral-500 ml-4">Email Address</label>
              <div className="relative group">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-500 group-focus-within:text-orange-500 transition-colors" size={18} />
                <input 
                  type="email" 
                  required
                  placeholder="user@example.com"
                  className="w-full bg-neutral-800/50 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-sm focus:border-orange-500/50 focus:bg-white/[0.07] outline-none transition-all text-neutral-50"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-neutral-500 ml-4">Password</label>
              <div className="relative group">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-500 group-focus-within:text-orange-500 transition-colors" size={18} />
                <input 
                  type="password" 
                  required
                  placeholder="••••••••"
                  className="w-full bg-neutral-800/50 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-sm focus:border-orange-500/50 focus:bg-white/[0.07] outline-none transition-all text-neutral-50"
                />
              </div>
            </div>

            <button 
              disabled={loading}
              className="w-full bg-white text-black py-4 rounded-2xl font-black uppercase tracking-[0.2em] text-xs hover:bg-orange-500 transition-all flex items-center justify-center gap-2 group disabled:opacity-50"
            >
              {loading ? <Loader2 className="animate-spin" size={18} /> : (
                <>
                  Create Account
                  <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </button>
          </form>

          <div className="mt-10 pt-8 border-t border-white/5 text-center">
            <p className="text-xs text-neutral-400">
              Already have an account? <Link to="/login" className="text-orange-500 font-bold hover:underline">Sign in</Link>
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

// --- Main Layout ---

function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { user, setUser, settings, adminSettings, snowEnabled, setSnowEnabled } = useContext(AuthContext)!;
  const { t } = useTranslation();
  const [isAfk, setIsAfk] = useState(false);
  const navigate = useNavigate();
  const location = window.location.pathname;

  useEffect(() => {
    let interval: any;
    if (isAfk) {
      interval = setInterval(() => {
        fetch('/api/economy/afk', { method: 'POST' })
          .then(res => res.json())
          .then(data => {
            setUser(prev => prev ? { ...prev, coins: data.coins, afk_time: data.afk_time } : null);
          });
      }, 5000);
    }
    return () => clearInterval(interval);
  }, [isAfk, setUser]);

  if (!user || !settings) return <Loader />;

  return (
    <div className="bg-neutral-900 min-h-screen text-neutral-50 font-sans selection:bg-orange-500 selection:text-black flex flex-col relative overflow-hidden">
      {adminSettings?.global_dashboard_bg && (
        <div className="fixed inset-0 z-0 opacity-10 pointer-events-none">
          <img src={adminSettings.global_dashboard_bg} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
        </div>
      )}
      <div className="fixed inset-0 z-0 bg-gradient-to-b from-transparent to-[#0a0a0a] pointer-events-none" />
      
      {/* Sidebar */}
      <aside className="fixed left-0 top-0 h-full w-64 bg-neutral-900 border-r border-white/10 p-6 flex flex-col gap-8 z-50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center font-bold text-black text-xl">S</div>
          <h1 className="text-xl font-bold tracking-tighter italic uppercase">{settings.dashboard_name}</h1>
        </div>

        <nav className="flex flex-col gap-2">
          <NavItem active={location === '/dashboard'} onClick={() => navigate('/dashboard')} icon={<LayoutDashboard size={20} />} label={t('sidebar.dashboard')} />
          <NavItem active={location === '/servers'} onClick={() => navigate('/servers')} icon={<Server size={20} />} label={t('sidebar.my_servers')} />
          <NavItem active={location === '/store'} onClick={() => navigate('/store')} icon={<Coins size={20} />} label={t('sidebar.coin_store')} />
          <NavItem active={location === '/tickets'} onClick={() => navigate('/tickets')} icon={<MessageSquare size={20} />} label="Support Tickets" />
          
          {user.root_admin && (
            <div className="mt-4 pt-4 border-t border-white/5 space-y-2">
              <p className="px-4 text-[10px] font-black uppercase tracking-widest text-orange-500 mb-2">{t('sidebar.admin_control')}</p>
              <NavItem active={location.startsWith('/admin')} onClick={() => navigate('/admin')} icon={<ShieldCheck size={20} />} label={t('sidebar.admin_panel')} />
            </div>
          )}
        </nav>

        <div className="mt-auto pt-6 border-t border-white/5 space-y-4">
          <button 
            onClick={() => setIsAfk(!isAfk)}
            className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-xs transition-all ${
              isAfk ? 'bg-green-500 text-black animate-pulse' : 'bg-white/5 text-white/50 hover:bg-white/10'
            }`}
          >
            <Activity size={14} /> {isAfk ? t('sidebar.afk_on') : t('sidebar.afk_off')}
          </button>

          <button 
            onClick={() => setSnowEnabled(!snowEnabled)}
            className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-xs transition-all bg-white/5 text-white/50 hover:bg-white/10`}
          >
            <Snowflake size={14} className={snowEnabled ? 'text-blue-400' : ''} /> {snowEnabled ? t('sidebar.snow_disable') : t('sidebar.snow_enable')}
          </button>
          
          <div className="flex items-center gap-3 p-3 bg-white/5 rounded-xl">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-500 to-red-600" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{user.username}</p>
              <p className="text-xs text-white/50 truncate">{t('sidebar.premium_user')}</p>
            </div>
            <button onClick={() => navigate('/login')} className="text-white/30 hover:text-white transition-colors" title={t('sidebar.log_out')}>
              <LogOut size={18} />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="pl-64 flex-1 flex flex-col">
        {/* Header */}
        <header className="h-20 border-bottom border-white/10 px-8 flex items-center justify-between sticky top-0 bg-[#050505]/80 backdrop-blur-xl z-40">
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-2 text-orange-500 bg-orange-500/10 px-3 py-1.5 rounded-full border border-orange-500/20">
              <Coins size={16} />
              <span className="text-sm font-bold">{user.coins.toFixed(2)} {t('header.coins')}</span>
            </div>
            <div className="flex items-center gap-6 text-sm text-white/50">
              <span className="flex items-center gap-2"><Activity size={14} /> {t('header.afk')}: {user.afk_time}m</span>
              <span className="flex items-center gap-2"><ShieldCheck size={14} /> {t('header.protected')}</span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <LanguageSwitcher />
            <button className="p-2 hover:bg-white/5 rounded-lg transition-colors text-white/50 hover:text-white">
              <MessageSquare size={20} />
            </button>
          </div>
        </header>

        <div className="p-8 max-w-7xl mx-auto w-full flex-1">
          {children}
        </div>

        <Footer />
      </main>
    </div>
  );
}

// --- App Core ---

export default function App() {
  const [user, setUser] = useState<UserData | null>(null);
  const [settings, setSettings] = useState<SettingsData | null>(null);
  const [adminSettings, setAdminSettings] = useState<AdminSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [snowEnabled, setSnowEnabled] = useState(true);

  useEffect(() => {
    const init = async () => {
      try {
        const [u, s, as] = await Promise.all([
          fetch('/api/user').then(res => res.json()),
          fetch('/api/settings').then(res => res.json()),
          fetch('/api/admin/settings').then(res => res.json())
        ]);
        setUser(u);
        setSettings(s);
        setAdminSettings(as);
      } catch (e) {
        console.error("Init failed", e);
      } finally {
        setTimeout(() => setLoading(false), 2000); // Show loader for effect
      }
    };
    init();
  }, []);

  return (
    <AuthContext.Provider value={{ 
      user, 
      setUser, 
      settings, 
      setSettings,
      adminSettings, 
      setAdminSettings, 
      loading,
      snowEnabled,
      setSnowEnabled
    }}>
      <Toaster theme="dark" position="top-right" />
      <Router>
        <Snowflakes enabled={snowEnabled} />
        <AnimatePresence mode="wait">
          {loading ? (
            <Loader key="loader" />
          ) : (
            <Routes>
              <Route path="/login" element={<LoginPage />} />
              <Route path="/register" element={<RegisterPage />} />
              
              {/* User Routes */}
              <Route path="/dashboard" element={<ProtectedRoute><DashboardLayout><DashboardContent /></DashboardLayout></ProtectedRoute>} />
              <Route path="/servers" element={<ProtectedRoute><DashboardLayout><ServersContent /></DashboardLayout></ProtectedRoute>} />
              <Route path="/store" element={<ProtectedRoute><DashboardLayout><StoreContent /></DashboardLayout></ProtectedRoute>} />
              <Route path="/tickets" element={<ProtectedRoute><DashboardLayout><TicketsContent /></DashboardLayout></ProtectedRoute>} />
              <Route path="/server/:id" element={<ProtectedRoute><DashboardLayout><ServerDashboard /></DashboardLayout></ProtectedRoute>} />

              {/* Admin Routes */}
              <Route path="/admin" element={<ProtectedRoute adminOnly><AdminLayout><AdminDashboard /></AdminLayout></ProtectedRoute>} />
              <Route path="/admin/mapper" element={<ProtectedRoute adminOnly><AdminLayout><DeployMapper /></AdminLayout></ProtectedRoute>} />
              <Route path="/admin/servers" element={<ProtectedRoute adminOnly><AdminLayout><ServerManagement /></AdminLayout></ProtectedRoute>} />
              <Route path="/admin/automation" element={<ProtectedRoute adminOnly><AdminLayout><AutomationUI /></AdminLayout></ProtectedRoute>} />
              <Route path="/admin/theme" element={<ProtectedRoute adminOnly><AdminLayout><ThemeSettings /></AdminLayout></ProtectedRoute>} />
              <Route path="/admin/redeem" element={<ProtectedRoute adminOnly><AdminLayout><RedeemCodeManagement /></AdminLayout></ProtectedRoute>} />
              <Route path="/software" element={<ProtectedRoute adminOnly><AdminLayout><SoftwareContent /></AdminLayout></ProtectedRoute>} />
              <Route path="/extensions" element={<ProtectedRoute adminOnly><AdminLayout><ExtensionsContent /></AdminLayout></ProtectedRoute>} />
              <Route path="/settings" element={<ProtectedRoute adminOnly><AdminLayout><SettingsContent /></AdminLayout></ProtectedRoute>} />

              <Route path="*" element={<Navigate to="/login" replace />} />
            </Routes>
          )}
        </AnimatePresence>
        
        {/* Global Snow Toggle (Hidden, but can be triggered by Admin or Keybind) */}
        <button 
          onClick={() => setSnowEnabled(!snowEnabled)}
          className="fixed bottom-4 right-4 z-[100] p-2 bg-white/5 hover:bg-white/10 rounded-full text-white/20 hover:text-white transition-all border border-white/10"
          title="Toggle Snowflakes"
        >
          <Snowflake size={14} />
        </button>
      </Router>
    </AuthContext.Provider>
  );
}

function ProtectedRoute({ children, adminOnly }: { children: React.ReactNode, adminOnly?: boolean }) {
  const { user, loading } = useContext(AuthContext)!;
  
  if (loading) return <Loader />;
  if (!user) return <Navigate to="/login" replace />;
  if (adminOnly && !user.root_admin) return <Navigate to="/dashboard" replace />;
  
  return <>{children}</>;
}

function ManagementCard({ icon, title, description, onClick }: { icon: React.ReactNode, title: string, description: string, onClick?: () => void }) {
  return (
    <div onClick={onClick} className="bg-neutral-900 border border-white/10 p-6 rounded-3xl hover:border-orange-500/30 transition-all group cursor-pointer">
      <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center text-orange-500 group-hover:scale-110 transition-transform mb-4">
        {icon}
      </div>
      <h4 className="text-lg font-bold mb-2 text-neutral-50">{title}</h4>
      <p className="text-xs text-neutral-400 leading-relaxed">{description}</p>
      <div className="mt-6 flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-orange-500 opacity-0 group-hover:opacity-100 transition-opacity">
        Open Tool <ArrowRight size={12} />
      </div>
    </div>
  );
}

// --- Admin Components ---

function AdminLayout({ children }: { children: React.ReactNode }) {
  const { user, adminSettings, setAdminSettings } = useContext(AuthContext)!;
  const navigate = useNavigate();

  if (user?.role !== 'admin') return <Navigate to="/dashboard" replace />;

  const isLight = adminSettings?.admin_theme === 'light';

  return (
    <div className={`min-h-screen transition-colors duration-300 flex flex-col ${isLight ? 'bg-white text-black' : 'bg-neutral-900 text-neutral-50'}`}>
      <div className="flex flex-1">
        {/* Admin Sidebar */}
        <aside className={`w-64 h-screen sticky top-0 border-r p-6 flex flex-col gap-8 ${isLight ? 'bg-gray-50 border-gray-200' : 'bg-neutral-900 border-white/10'}`}>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center font-bold text-black text-xl">A</div>
            <h1 className="text-xl font-bold tracking-tighter italic uppercase">Admin Panel</h1>
          </div>

          <div className="flex-1 overflow-y-auto pb-24 custom-scrollbar">
            <nav className="flex flex-col gap-2">
              <NavItem active={window.location.pathname === '/admin'} onClick={() => navigate('/admin')} icon={<LayoutDashboard size={20} />} label="Overview" />
              <NavItem active={window.location.pathname === '/admin/mapper'} onClick={() => navigate('/admin/mapper')} icon={<Scissors size={20} />} label="Deploy Mapper" />
              <NavItem active={window.location.pathname === '/admin/servers'} onClick={() => navigate('/admin/servers')} icon={<Server size={20} />} label="Server Queue" />
              <NavItem active={window.location.pathname === '/admin/automation'} onClick={() => navigate('/admin/automation')} icon={<Clock size={20} />} label="Automation" />
              <NavItem active={window.location.pathname === '/admin/theme'} onClick={() => navigate('/admin/theme')} icon={<Settings size={20} />} label="Theme Settings" />
              <NavItem active={window.location.pathname === '/admin/redeem'} onClick={() => navigate('/admin/redeem')} icon={<Database size={20} />} label="Redeem Codes" />
              <div className="mt-4 pt-4 border-t border-white/5 space-y-2">
                <p className="px-4 text-[10px] font-black uppercase tracking-widest text-orange-500 mb-2">System Management</p>
                <NavItem active={window.location.pathname === '/software'} onClick={() => navigate('/software')} icon={<Database size={20} />} label="Software" />
                <NavItem active={window.location.pathname === '/extensions'} onClick={() => navigate('/extensions')} icon={<Puzzle size={20} />} label="Extensions" />
                <NavItem active={window.location.pathname === '/settings'} onClick={() => navigate('/settings')} icon={<Settings size={20} />} label="Settings" />
              </div>
              <NavItem active={false} onClick={() => navigate('/dashboard')} icon={<ArrowRight size={20} />} label="Back to User UI" />
            </nav>
          </div>

          <div className="mt-auto pt-6 border-t border-white/5">
            <button 
              onClick={() => {
                const newTheme = isLight ? 'dark' : 'light';
                fetch('/api/admin/settings', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ admin_theme: newTheme })
                }).then(() => setAdminSettings(prev => prev ? { ...prev, admin_theme: newTheme as 'light' | 'dark' } : null));
              }}
              className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-xs transition-all ${isLight ? 'bg-black text-white' : 'bg-white text-black'}`}
            >
              {isLight ? <Lock size={14} /> : <Eye size={14} />} {isLight ? 'DARK MODE' : 'LIGHT MODE'}
            </button>
          </div>
        </aside>

        <main className="flex-1 p-12">
          {children}
        </main>
      </div>
      <Footer />
    </div>
  );
}

function AdminDashboard() {
  const [servers, setServers] = useState<ServerData[]>([]);
  useEffect(() => {
    fetch('/api/servers').then(res => res.json()).then(setServers);
  }, []);

  const pending = servers.filter(s => s.approval_status === 'pending').length;
  const suspended = servers.filter(s => s.auto_suspended).length;

  return (
    <div className="space-y-12">
      <h2 className="text-4xl font-black tracking-tighter italic uppercase">Admin Overview</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <StatCard icon={<AlertTriangle className="text-orange-500" />} label="Pending Approval" value={pending.toString()} sub="Servers waiting" />
        <StatCard icon={<Lock className="text-red-500" />} label="Auto-Suspended" value={suspended.toString()} sub="Resource violations" />
        <StatCard icon={<Users className="text-blue-500" />} label="Total Users" value="1,248" sub="Active accounts" />
      </div>
    </div>
  );
}

function DeployMapper() {
  const [mapper, setMapper] = useState<MapperData | null>(null);
  const { adminSettings, setAdminSettings } = useContext(AuthContext)!;
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalType, setModalType] = useState<'nodes' | 'eggs'>('nodes');
  const [formData, setFormData] = useState({ custom_name: '', actual_id: '' });

  useEffect(() => {
    fetch('/api/admin/mappers').then(res => res.json()).then(setMapper);
  }, []);

  const openModal = (type: 'nodes' | 'eggs') => {
    setModalType(type);
    setFormData({ custom_name: '', actual_id: '' });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.custom_name && formData.actual_id) {
      fetch(`/api/admin/mappers/${modalType}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      }).then(res => res.json()).then(data => {
        setMapper(prev => prev ? { ...prev, [modalType]: data } : null);
        setIsModalOpen(false);
      });
    }
  };

  const deleteMapping = (type: 'nodes' | 'eggs', id: number) => {
    if (confirm("Are you sure you want to delete this mapping?")) {
      fetch(`/api/admin/mappers/${type}/${id}`, { method: 'DELETE' })
        .then(res => res.json())
        .then(data => setMapper(prev => prev ? { ...prev, [type]: data } : null));
    }
  };

  return (
    <div className="space-y-12">
      <div className="flex items-center justify-between">
        <h2 className="text-4xl font-black tracking-tighter italic uppercase">Deploy Mapper</h2>
        <div className="flex items-center gap-4">
          <span className="text-xs font-bold uppercase opacity-50">Show Node IDs</span>
          <button 
            onClick={() => {
              const newVal = !adminSettings?.show_node_ids;
              fetch('/api/admin/settings', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ show_node_ids: newVal })
              }).then(() => setAdminSettings(prev => prev ? { ...prev, show_node_ids: newVal } : null));
            }}
            className={`w-12 h-6 rounded-full transition-colors relative ${adminSettings?.show_node_ids ? 'bg-orange-500' : 'bg-white/10'}`}
          >
            <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${adminSettings?.show_node_ids ? 'left-7' : 'left-1'}`} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold uppercase italic">Node Mappings</h3>
            <button onClick={() => openModal('nodes')} className="p-2 bg-orange-500 rounded-lg text-black hover:bg-orange-600 transition-all"><Plus size={18} /></button>
          </div>
          <div className="bg-white/5 rounded-3xl border border-white/10 overflow-hidden">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-white/10 bg-white/5">
                  <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest opacity-50">Custom Name</th>
                  <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest opacity-50">Actual ID</th>
                  <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest opacity-50">Actions</th>
                </tr>
              </thead>
              <tbody>
                {mapper?.nodes?.map(node => (
                  <tr key={node.id} className="border-b border-white/5 hover:bg-white/[0.02] transition-colors">
                    <td className="px-6 py-4 font-bold">{node.custom_name}</td>
                    <td className="px-6 py-4 font-mono text-xs text-orange-500">{node.actual_id}</td>
                    <td className="px-6 py-4">
                      <button onClick={() => deleteMapping('nodes', node.id)} className="text-red-500 hover:text-red-400 transition-colors">
                        <X size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold uppercase italic">Egg Mappings</h3>
            <button onClick={() => openModal('eggs')} className="p-2 bg-orange-500 rounded-lg text-black hover:bg-orange-600 transition-all"><Plus size={18} /></button>
          </div>
          <div className="bg-white/5 rounded-3xl border border-white/10 overflow-hidden">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-white/10 bg-white/5">
                  <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest opacity-50">Custom Name</th>
                  <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest opacity-50">Actual ID</th>
                  <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest opacity-50">Actions</th>
                </tr>
              </thead>
              <tbody>
                {mapper?.eggs?.map(egg => (
                  <tr key={egg.id} className="border-b border-white/5 hover:bg-white/[0.02] transition-colors">
                    <td className="px-6 py-4 font-bold">{egg.custom_name}</td>
                    <td className="px-6 py-4 font-mono text-xs text-orange-500">{egg.actual_id}</td>
                    <td className="px-6 py-4">
                      <button onClick={() => deleteMapping('eggs', egg.id)} className="text-red-500 hover:text-red-400 transition-colors">
                        <X size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#0a0a0a] border border-white/10 rounded-3xl p-8 max-w-md w-full relative"
            >
              <button 
                onClick={() => setIsModalOpen(false)}
                className="absolute top-6 right-6 text-white/50 hover:text-white transition-colors"
              >
                <X size={24} />
              </button>
              
              <h3 className="text-2xl font-black italic uppercase mb-6">Add {modalType === 'nodes' ? 'Node' : 'Egg'} Mapping</h3>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest opacity-50">Custom Name</label>
                  <input 
                    type="text" 
                    required
                    value={formData.custom_name}
                    onChange={e => setFormData({...formData, custom_name: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-orange-500 transition-colors"
                    placeholder={`e.g. Premium ${modalType === 'nodes' ? 'Node' : 'Egg'}`}
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest opacity-50">Actual {modalType === 'nodes' ? 'Node' : 'Egg'} ID</label>
                  <input 
                    type="text" 
                    required
                    value={formData.actual_id}
                    onChange={e => setFormData({...formData, actual_id: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-orange-500 transition-colors font-mono"
                    placeholder="e.g. 1"
                  />
                </div>

                <button 
                  type="submit"
                  className="w-full py-4 bg-orange-500 text-black font-black uppercase tracking-widest italic rounded-xl hover:bg-orange-600 transition-colors"
                >
                  Save Mapping
                </button>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ServerManagement() {
  const [servers, setServers] = useState<ServerData[]>([]);
  useEffect(() => {
    fetch('/api/servers').then(res => res.json()).then(setServers);
  }, []);

  const handleApprove = (id: number) => {
    fetch(`/api/admin/servers/approve/${id}`, { method: 'POST' })
      .then(res => res.json())
      .then(updated => setServers(prev => prev.map(s => s.id === id ? updated : s)));
  };

  const handleSuspend = (id: number) => {
    fetch(`/api/admin/servers/suspend/${id}`, { method: 'POST' })
      .then(res => res.json())
      .then(updated => setServers(prev => prev.map(s => s.id === id ? updated : s)));
  };

  return (
    <div className="space-y-12">
      <h2 className="text-4xl font-black tracking-tighter italic uppercase">Server Management</h2>
      
      <div className="space-y-6">
        <h3 className="text-xl font-bold uppercase italic">Approval Queue</h3>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {servers.filter(s => s.approval_status === 'pending').map(server => (
            <div key={server.id} className="bg-white/5 border border-white/10 p-6 rounded-3xl flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-orange-500/10 flex items-center justify-center text-orange-500 font-black italic">S</div>
                <div>
                  <h4 className="font-bold">{server.name}</h4>
                  <p className="text-[10px] font-mono text-neutral-400 uppercase tracking-widest">{server.software_type} | {server.resources.ram}MB</p>
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={() => handleApprove(server.id)} className="px-4 py-2 bg-green-500 text-black rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-green-600 transition-all">Approve</button>
                <button className="px-4 py-2 bg-red-500/10 text-red-500 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-red-500/20 transition-all border border-red-500/20">Reject</button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="space-y-6">
        <h3 className="text-xl font-bold uppercase italic">All Servers</h3>
        <div className="bg-white/5 rounded-3xl border border-white/10 overflow-hidden">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-white/10 bg-white/5">
                <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest opacity-50">Server Name</th>
                <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest opacity-50">Status</th>
                <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest opacity-50">Actions</th>
              </tr>
            </thead>
            <tbody>
              {servers.map(server => (
                <tr key={server.id} className="border-b border-white/5 hover:bg-white/[0.02] transition-colors">
                  <td className="px-6 py-4 font-bold">{server.name}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded text-[8px] font-black uppercase tracking-widest ${server.auto_suspended ? 'bg-red-500/10 text-red-500 border border-red-500/20' : 'bg-green-500/10 text-green-500 border border-green-500/20'}`}>
                      {server.auto_suspended ? 'Suspended' : 'Active'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <button onClick={() => handleSuspend(server.id)} className="text-[10px] font-black uppercase tracking-widest text-orange-500 hover:underline">
                      {server.auto_suspended ? 'Unsuspend' : 'Suspend'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function AutomationUI() {
  const { adminSettings, setAdminSettings } = useContext(AuthContext)!;

  const updateAuto = (type: 'db_backups' | 'node_backups', key: string, value: any) => {
    const newAuto = { ...adminSettings!.automation, [type]: { ...adminSettings!.automation[type], [key]: value } };
    fetch('/api/admin/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ automation: newAuto })
    }).then(() => setAdminSettings(prev => prev ? { ...prev, automation: newAuto } : null));
  };

  return (
    <div className="space-y-12">
      <h2 className="text-4xl font-black tracking-tighter italic uppercase">Automation Controls</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div className="space-y-6">
          <h3 className="text-xl font-bold uppercase italic flex items-center gap-3">
            <Database size={24} className="text-orange-500" />
            Database Backups
          </h3>
          <div className="bg-white/5 border border-white/10 p-8 rounded-3xl space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-bold">Enable Auto DB Backups</h4>
                <p className="text-xs text-neutral-400">Automated SQL dumps and storage</p>
              </div>
              <button 
                onClick={() => updateAuto('db_backups', 'enabled', !adminSettings?.automation.db_backups.enabled)}
                className={`w-12 h-6 rounded-full transition-colors relative ${adminSettings?.automation.db_backups.enabled ? 'bg-orange-500' : 'bg-white/10'}`}
              >
                <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${adminSettings?.automation.db_backups.enabled ? 'left-7' : 'left-1'}`} />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest opacity-50">Frequency</label>
                <select 
                  value={adminSettings?.automation.db_backups.frequency}
                  onChange={(e) => updateAuto('db_backups', 'frequency', e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-sm outline-none"
                >
                  <option value="hourly">Hourly</option>
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest opacity-50">Retention (Days)</label>
                <input 
                  type="number" 
                  value={adminSettings?.automation.db_backups.retention}
                  onChange={(e) => updateAuto('db_backups', 'retention', parseInt(e.target.value))}
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-sm outline-none" 
                />
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <h3 className="text-xl font-bold uppercase italic flex items-center gap-3">
            <Server size={24} className="text-blue-500" />
            Server & Node Backups
          </h3>
          <div className="bg-white/5 border border-white/10 p-8 rounded-3xl space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-bold">Enable Node-level Backups</h4>
                <p className="text-xs text-neutral-400">Full node snapshots and server data</p>
              </div>
              <button 
                onClick={() => updateAuto('node_backups', 'enabled', !adminSettings?.automation.node_backups.enabled)}
                className={`w-12 h-6 rounded-full transition-colors relative ${adminSettings?.automation.node_backups.enabled ? 'bg-blue-500' : 'bg-white/10'}`}
              >
                <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${adminSettings?.automation.node_backups.enabled ? 'left-7' : 'left-1'}`} />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest opacity-50">Frequency</label>
                <select 
                  value={adminSettings?.automation.node_backups.frequency}
                  onChange={(e) => updateAuto('node_backups', 'frequency', e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-sm outline-none"
                >
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                  <option value="monthly">Monthly</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest opacity-50">Retention (Weeks)</label>
                <input 
                  type="number" 
                  value={adminSettings?.automation.node_backups.retention}
                  onChange={(e) => updateAuto('node_backups', 'retention', parseInt(e.target.value))}
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-sm outline-none" 
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ThemeSettings() {
  const { settings, setSettings, adminSettings, setAdminSettings } = useContext(AuthContext)!;
  const [localAdminSettings, setLocalAdminSettings] = useState<AdminSettings | null>(null);
  const [localSettings, setLocalSettings] = useState<SettingsData | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (adminSettings && !localAdminSettings) setLocalAdminSettings(JSON.parse(JSON.stringify(adminSettings)));
    if (settings && !localSettings) setLocalSettings(JSON.parse(JSON.stringify(settings)));
  }, [adminSettings, settings]);

  if (!localAdminSettings || !localSettings) return <Loader />;

  const handleSave = async () => {
    setSaving(true);
    try {
      const response = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...localAdminSettings,
          dashboard_name: localSettings.dashboard_name,
          discord_link: localSettings.discord_link,
          resource_upgrade_toggle: localSettings.resource_upgrade_toggle
        })
      });
      
      if (!response.ok) throw new Error('Failed to save');
      
      const updatedAdminSettings = await response.json();
      setAdminSettings(updatedAdminSettings);
      setSettings(prev => prev ? {
        ...prev,
        dashboard_name: localSettings.dashboard_name,
        discord_link: localSettings.discord_link,
        resource_upgrade_toggle: localSettings.resource_upgrade_toggle
      } : null);
      
      alert("✅ Settings saved successfully!");
    } catch (error) {
      console.error(error);
      alert("❌ Failed to save settings. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const updateLocalSettings = (key: string, value: any) => {
    setLocalSettings(prev => prev ? { ...prev, [key]: value } : null);
  };

  const updateLocalAdminSettings = (key: string, value: any) => {
    setLocalAdminSettings(prev => prev ? { ...prev, [key]: value } : null);
  };

  const updatePayments = (method: string, action: 'add' | 'remove') => {
    let newMethods = [...localAdminSettings.payment_methods];
    if (action === 'add') {
      if (!newMethods.includes(method)) newMethods.push(method);
    } else {
      newMethods = newMethods.filter(m => m !== method);
    }
    updateLocalAdminSettings('payment_methods', newMethods);
  };

  const updateSpecs = (key: string, value: any) => {
    const newSpecs = { ...localAdminSettings.default_user_specs, [key]: value };
    updateLocalAdminSettings('default_user_specs', newSpecs);
  };

  const updatePricing = (key: string, value: any) => {
    const newPricing = { ...localAdminSettings.upgrade_pricing, [key]: value };
    updateLocalAdminSettings('upgrade_pricing', newPricing);
  };

  return (
    <div className="space-y-12 pb-20">
      <div className="flex items-center justify-between">
        <h2 className="text-4xl font-black tracking-tighter italic uppercase">Theme & Global Settings</h2>
        <button 
          onClick={handleSave}
          disabled={saving}
          className="px-8 py-4 bg-orange-500 text-black rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-orange-400 transition-all flex items-center gap-2 shadow-lg shadow-orange-500/20 disabled:opacity-50"
        >
          {saving ? <Loader2 size={18} className="animate-spin" /> : <ShieldCheck size={18} />}
          {saving ? 'Saving...' : 'Save All Changes'}
        </button>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div className="space-y-8">
          <div className="space-y-4">
            <h3 className="text-xl font-bold uppercase italic">General Configuration</h3>
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-neutral-500">Dashboard Name</label>
                <input 
                  type="text" 
                  value={localSettings.dashboard_name} 
                  onChange={(e) => updateLocalSettings('dashboard_name', e.target.value)}
                  className="w-full bg-neutral-800/50 border border-white/10 rounded-xl p-4 text-sm font-bold outline-none focus:border-orange-500/50 text-neutral-50"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-neutral-500">Discord Link</label>
                <input 
                  type="text" 
                  value={localSettings.discord_link} 
                  onChange={(e) => updateLocalSettings('discord_link', e.target.value)}
                  className="w-full bg-neutral-800/50 border border-white/10 rounded-xl p-4 text-sm outline-none focus:border-orange-500/50 text-neutral-50"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-neutral-500">Global Dashboard Background</label>
                <div className="flex gap-2">
                  <input 
                    type="text" 
                    value={localAdminSettings.global_dashboard_bg} 
                    onChange={(e) => updateLocalAdminSettings('global_dashboard_bg', e.target.value)}
                    className="flex-1 bg-neutral-800/50 border border-white/10 rounded-xl p-4 text-sm outline-none focus:border-orange-500/50 text-neutral-50"
                    placeholder="https://..."
                  />
                  <label className="p-4 bg-neutral-800/50 border border-white/10 rounded-xl hover:bg-white/10 transition-all cursor-pointer text-neutral-50">
                    <Upload size={18} />
                    <input 
                      type="file" 
                      className="hidden" 
                      accept="image/*"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onloadend = () => {
                            updateLocalAdminSettings('global_dashboard_bg', reader.result);
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                    />
                  </label>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-xl font-bold uppercase italic">AFK Earning Settings</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-neutral-500">Coins per interval</label>
                <input 
                  type="number" 
                  step="0.01"
                  value={localAdminSettings.afk_coin_amount} 
                  onChange={(e) => updateLocalAdminSettings('afk_coin_amount', parseFloat(e.target.value))}
                  className="w-full bg-neutral-800/50 border border-white/10 rounded-xl p-4 text-sm outline-none focus:border-orange-500/50 text-neutral-50"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-neutral-500">Interval (Seconds)</label>
                <input 
                  type="number" 
                  value={localAdminSettings.afk_time_interval} 
                  onChange={(e) => updateLocalAdminSettings('afk_time_interval', parseInt(e.target.value))}
                  className="w-full bg-neutral-800/50 border border-white/10 rounded-xl p-4 text-sm outline-none focus:border-orange-500/50 text-neutral-50"
                />
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-xl font-bold uppercase italic">Payment Methods</h3>
            <div className="flex flex-wrap gap-2">
              {localAdminSettings.payment_methods.map(method => (
                <div key={method} className="flex items-center gap-2 px-4 py-2 bg-neutral-800/50 border border-white/10 rounded-xl text-xs font-bold group text-neutral-50">
                  {method}
                  <button onClick={() => updatePayments(method, 'remove')} className="text-neutral-500 hover:text-red-500 transition-colors">
                    <X size={12} />
                  </button>
                </div>
              ))}
              <button 
                onClick={() => {
                  const method = prompt("Enter new payment method name:");
                  if (method) updatePayments(method, 'add');
                }}
                className="p-2 bg-neutral-800/50 border border-white/10 rounded-xl hover:bg-white/10 transition-all text-neutral-50"
              >
                <Plus size={16} />
              </button>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-xl font-bold uppercase italic">Resource Upgrade Pricing (Coins)</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-neutral-500">RAM (per 128MB)</label>
                <input type="number" value={localAdminSettings.upgrade_pricing.ram} onChange={(e) => updatePricing('ram', parseInt(e.target.value))} className="w-full bg-neutral-800/50 border border-white/10 rounded-xl p-3 text-sm outline-none text-neutral-50" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-neutral-500">CPU (per 10%)</label>
                <input type="number" value={localAdminSettings.upgrade_pricing.cpu} onChange={(e) => updatePricing('cpu', parseInt(e.target.value))} className="w-full bg-neutral-800/50 border border-white/10 rounded-xl p-3 text-sm outline-none text-neutral-50" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-neutral-500">Disk (per 1GB)</label>
                <input type="number" value={localAdminSettings.upgrade_pricing.disk} onChange={(e) => updatePricing('disk', parseInt(e.target.value))} className="w-full bg-neutral-800/50 border border-white/10 rounded-xl p-3 text-sm outline-none text-neutral-50" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-neutral-500">Server Slot</label>
                <input type="number" value={localAdminSettings.upgrade_pricing.servers} onChange={(e) => updatePricing('servers', parseInt(e.target.value))} className="w-full bg-neutral-800/50 border border-white/10 rounded-xl p-3 text-sm outline-none text-neutral-50" />
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="space-y-4">
            <h3 className="text-xl font-bold uppercase italic">Default User Specs</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-neutral-500">RAM (MB)</label>
                <input type="number" value={localAdminSettings.default_user_specs.ram} onChange={(e) => updateSpecs('ram', parseInt(e.target.value))} className="w-full bg-neutral-800/50 border border-white/10 rounded-xl p-4 text-sm outline-none text-neutral-50" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-neutral-500">CPU (%)</label>
                <input type="number" value={localAdminSettings.default_user_specs.cpu} onChange={(e) => updateSpecs('cpu', parseInt(e.target.value))} className="w-full bg-neutral-800/50 border border-white/10 rounded-xl p-4 text-sm outline-none text-neutral-50" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-neutral-500">Disk (MB)</label>
                <input type="number" value={localAdminSettings.default_user_specs.disk} onChange={(e) => updateSpecs('disk', parseInt(e.target.value))} className="w-full bg-neutral-800/50 border border-white/10 rounded-xl p-4 text-sm outline-none text-neutral-50" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-neutral-500">Initial Coins</label>
                <input type="number" value={localAdminSettings.default_user_specs.coins} onChange={(e) => updateSpecs('coins', parseInt(e.target.value))} className="w-full bg-neutral-800/50 border border-white/10 rounded-xl p-4 text-sm outline-none text-neutral-50" />
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-xl font-bold uppercase italic">Discord Bot Management</h3>
            <div className="p-6 bg-neutral-900 border border-white/10 rounded-3xl space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-neutral-500">Bot Token</label>
                <input type="password" value={localAdminSettings.discord_bot.token} onChange={(e) => updateLocalAdminSettings('discord_bot', { ...localAdminSettings.discord_bot, token: e.target.value })} className="w-full bg-neutral-800/50 border border-white/10 rounded-xl p-4 text-sm outline-none text-neutral-50" placeholder="MTE..." />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-neutral-500">Guild/Server ID</label>
                  <input type="text" value={localAdminSettings.discord_bot.guild_id} onChange={(e) => updateLocalAdminSettings('discord_bot', { ...localAdminSettings.discord_bot, guild_id: e.target.value })} className="w-full bg-neutral-800/50 border border-white/10 rounded-xl p-4 text-sm outline-none text-neutral-50" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-neutral-500">Log Channel ID</label>
                  <input type="text" value={localAdminSettings.discord_bot.log_channel_id} onChange={(e) => updateLocalAdminSettings('discord_bot', { ...localAdminSettings.discord_bot, log_channel_id: e.target.value })} className="w-full bg-neutral-800/50 border border-white/10 rounded-xl p-4 text-sm outline-none text-neutral-50" />
                </div>
              </div>
              <div className="flex items-center justify-between p-4 bg-neutral-800/50 rounded-xl">
                <div>
                  <h4 className="font-bold text-neutral-50 text-sm">Notify on Server Creation</h4>
                  <p className="text-xs text-neutral-400">Send a message to the log channel when a server is created</p>
                </div>
                <button 
                  onClick={() => updateLocalAdminSettings('discord_bot', { ...localAdminSettings.discord_bot, notify_on_create: !localAdminSettings.discord_bot.notify_on_create })}
                  className={`w-12 h-6 rounded-full transition-colors relative ${localAdminSettings.discord_bot.notify_on_create ? 'bg-orange-500' : 'bg-white/10'}`}
                >
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${localAdminSettings.discord_bot.notify_on_create ? 'left-7' : 'left-1'}`} />
                </button>
              </div>
              <div className="flex items-center justify-between p-4 bg-neutral-800/50 rounded-xl">
                <div>
                  <h4 className="font-bold text-neutral-50 text-sm">Notify on Server Suspend</h4>
                  <p className="text-xs text-neutral-400">Send a message to the log channel when a server is suspended</p>
                </div>
                <button 
                  onClick={() => updateLocalAdminSettings('discord_bot', { ...localAdminSettings.discord_bot, notify_on_suspend: !localAdminSettings.discord_bot.notify_on_suspend })}
                  className={`w-12 h-6 rounded-full transition-colors relative ${localAdminSettings.discord_bot.notify_on_suspend ? 'bg-orange-500' : 'bg-white/10'}`}
                >
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${localAdminSettings.discord_bot.notify_on_suspend ? 'left-7' : 'left-1'}`} />
                </button>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-xl font-bold uppercase italic">Dashboard Controls</h3>
            <div className="flex items-center justify-between p-6 bg-neutral-900 border border-white/10 rounded-3xl">
              <div>
                <h4 className="font-bold text-neutral-50">Resource Upgrades</h4>
                <p className="text-xs text-neutral-400">Allow users to purchase resource upgrades with coins</p>
              </div>
              <button 
                onClick={() => updateLocalSettings('resource_upgrade_toggle', !localSettings.resource_upgrade_toggle)}
                className={`w-12 h-6 rounded-full transition-colors relative ${localSettings.resource_upgrade_toggle ? 'bg-green-500' : 'bg-white/10'}`}
              >
                <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${localSettings.resource_upgrade_toggle ? 'left-7' : 'left-1'}`} />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="fixed bottom-8 right-8 z-[60]">
        <button 
          onClick={handleSave}
          disabled={saving}
          className="px-10 py-5 bg-orange-500 text-black rounded-2xl font-black uppercase tracking-widest text-sm hover:bg-orange-400 transition-all flex items-center gap-3 shadow-2xl shadow-orange-500/40 disabled:opacity-50"
        >
          {saving ? <Loader2 size={20} className="animate-spin" /> : <ShieldCheck size={20} />}
          {saving ? 'Saving Changes...' : 'Save Settings'}
        </button>
      </div>
    </div>
  );
}

function DashboardContent() {
  const { user, setUser } = useContext(AuthContext)!;
  const { t } = useTranslation();
  const [servers, setServers] = useState<ServerData[]>([]);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [redeemCode, setRedeemCode] = useState('');
  const [redeemLoading, setRedeemLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    fetch('/api/servers').then(res => res.json()).then(setServers);
  }, []);

  const handleRedeem = () => {
    if (!redeemCode) return;
    setRedeemLoading(true);
    axios.post('/api/client/store/redeem', { code: redeemCode })
      .then(res => {
        const data = res.data;
        if (data.success) {
          setUser(prev => prev ? { ...prev, coins: data.new_balance } : null);
          toast.success(`Successfully redeemed ${data.reward} coins!`);
          setRedeemCode('');
        } else {
          toast.error(data.message || "Invalid or expired code.");
        }
      })
      .catch(err => {
        const errorMsg = err.response?.data?.message || "Redemption failed. Please try again.";
        toast.error(errorMsg);
      })
      .finally(() => setRedeemLoading(false));
  };

  const handleApprove = (id: number) => {
    fetch(`/api/admin/servers/approve/${id}`, { method: 'POST' })
      .then(res => res.json())
      .then(updated => {
        setServers(prev => prev.map(s => s.id === id ? updated : s));
      });
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-12"
    >
      <div className="flex items-center justify-between">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 flex-1">
          <StatCard icon={<Server className="text-blue-500" />} label={t('dashboard.servers')} value={`${servers.length}/${user!.limits.servers}`} sub={t('dashboard.active_instances')} />
          <StatCard icon={<Database className="text-purple-500" />} label={t('dashboard.ram')} value={`${user!.limits.ram}MB`} sub={t('dashboard.total_allocation')} />
          <StatCard icon={<Cpu className="text-orange-500" />} label={t('dashboard.cpu')} value={`${user!.limits.cpu}%`} sub={t('dashboard.processing_power')} />
          <StatCard icon={<HardDrive className="text-green-500" />} label={t('dashboard.disk')} value={`${user!.limits.disk}MB`} sub={t('dashboard.storage_limit')} />
        </div>
        <div className="flex flex-col gap-4 ml-8">
          {user?.root_admin && (
            <button 
              onClick={() => setIsCreateModalOpen(true)}
              className="px-8 py-4 bg-orange-500 text-black rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-orange-400 transition-all flex items-center gap-2 shadow-lg shadow-orange-500/20"
            >
              <Plus size={18} /> {t('dashboard.create_server')}
            </button>
          )}
          <div className="flex gap-2">
            <input 
              type="text" 
              value={redeemCode}
              onChange={(e) => setRedeemCode(e.target.value)}
              placeholder={t('dashboard.redeem_placeholder')}
              className="bg-neutral-800/50 border border-white/10 rounded-xl px-4 py-3 text-[10px] font-black uppercase tracking-widest outline-none focus:border-orange-500/50 w-32 text-neutral-50"
            />
            <button 
              onClick={handleRedeem}
              disabled={redeemLoading}
              className="px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-white/10 transition-all disabled:opacity-50"
            >
              {redeemLoading ? <Loader2 size={14} className="animate-spin" /> : t('dashboard.claim')}
            </button>
          </div>
        </div>
      </div>

      <div>
        <h2 className="text-2xl font-black tracking-tighter italic uppercase mb-6 flex items-center gap-3">
          {t('dashboard.active_servers')}
          <span className="text-[10px] font-mono bg-white/5 px-2 py-1 rounded text-neutral-500 uppercase tracking-widest not-italic">{t('dashboard.live_view')}</span>
        </h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {servers.map(server => (
            <ServerCard 
              key={server.id} 
              server={server} 
              onApprove={() => handleApprove(server.id)} 
              onClick={() => navigate(`/server/${server.id}`)}
            />
          ))}
        </div>
      </div>

      <ServerCreateModal isOpen={isCreateModalOpen} onClose={() => setIsCreateModalOpen(false)} onCreated={() => fetch('/api/servers').then(res => res.json()).then(setServers)} />
    </motion.div>
  );
}

function ServerCreateModal({ isOpen, onClose, onCreated }: { isOpen: boolean, onClose: () => void, onCreated: () => void }) {
  const [nodes, setNodes] = useState<MapperItem[]>([]);
  const [eggs, setEggs] = useState<MapperItem[]>([]);
  const [formData, setFormData] = useState({
    name: '',
    node_id: '',
    egg_id: '',
    ram: 1024,
    cpu: 100,
    disk: 5120
  });

  useEffect(() => {
    const fetchOptions = async () => {
      if (isOpen) {
        try {
          const [nodesRes, eggsRes] = await Promise.all([
            axios.get('/api/deploy/nodes'),
            axios.get('/api/deploy/eggs')
          ]);
          setNodes(Array.isArray(nodesRes.data) ? nodesRes.data : []);
          setEggs(Array.isArray(eggsRes.data) ? eggsRes.data : []);
        } catch (error) {
          console.error('Failed to fetch deployment options:', error);
        }
      }
    };
    fetchOptions();
  }, [isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await axios.post('/api/servers/create', formData);
      onCreated();
      onClose();
    } catch (error) {
      console.error('Failed to create server:', error);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        onClick={onClose} 
        className="absolute inset-0 bg-black/80 backdrop-blur-sm" 
      />
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="relative w-full max-w-xl bg-neutral-900 border border-white/10 rounded-[2.5rem] p-10 shadow-2xl overflow-hidden"
      >
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-orange-500 to-red-600" />
        
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-black tracking-tighter uppercase italic text-neutral-50">Request New Server</h2>
          <button onClick={onClose} className="text-neutral-500 hover:text-white transition-colors"><X size={24} /></button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-widest text-neutral-500 ml-2">Server Name</label>
            <input 
              required
              type="text" 
              value={formData.name}
              onChange={e => setFormData({...formData, name: e.target.value})}
              placeholder="My Awesome Server" 
              className="w-full bg-neutral-800/50 border border-white/10 rounded-2xl px-6 py-4 text-sm focus:border-orange-500 outline-none transition-all text-neutral-50"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-neutral-500 ml-2">Location (Node)</label>
              <div className="relative">
                <select 
                  required
                  value={formData.node_id}
                  onChange={e => setFormData({...formData, node_id: e.target.value})}
                  className="w-full bg-neutral-800/50 border border-white/10 rounded-2xl px-6 py-4 text-sm focus:border-orange-500 outline-none transition-all appearance-none text-neutral-50 pr-12"
                >
                  <option value="" disabled className="bg-neutral-900">Select Location</option>
                  {nodes.map(node => (
                    <option key={node.id} value={node.actual_id} className="bg-neutral-900">{node.custom_name}</option>
                  ))}
                </select>
                <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 text-neutral-500 pointer-events-none" size={18} />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-neutral-500 ml-2">Software (Egg)</label>
              <div className="relative">
                <select 
                  required
                  value={formData.egg_id}
                  onChange={e => setFormData({...formData, egg_id: e.target.value})}
                  className="w-full bg-neutral-800/50 border border-white/10 rounded-2xl px-6 py-4 text-sm focus:border-orange-500 outline-none transition-all appearance-none text-neutral-50 pr-12"
                >
                  <option value="" disabled className="bg-neutral-900">Select Software</option>
                  {eggs.map(egg => (
                    <option key={egg.id} value={egg.actual_id} className="bg-neutral-900">{egg.custom_name}</option>
                  ))}
                </select>
                <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 text-neutral-500 pointer-events-none" size={18} />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-white/30 ml-2">RAM (MB)</label>
              <input type="number" value={formData.ram} onChange={e => setFormData({...formData, ram: parseInt(e.target.value)})} className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-sm outline-none" />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-white/30 ml-2">CPU (%)</label>
              <input type="number" value={formData.cpu} onChange={e => setFormData({...formData, cpu: parseInt(e.target.value)})} className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-sm outline-none" />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-white/30 ml-2">Disk (MB)</label>
              <input type="number" value={formData.disk} onChange={e => setFormData({...formData, disk: parseInt(e.target.value)})} className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-sm outline-none" />
            </div>
          </div>

          <button type="submit" className="w-full py-5 bg-orange-500 text-black rounded-2xl font-black uppercase tracking-widest text-sm hover:bg-orange-400 transition-all mt-4">
            Deploy Server
          </button>
        </form>
      </motion.div>
    </div>
  );
}

function VersionChanger({ serverId }: { serverId: number }) {
  const [versions, setVersions] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [installing, setInstalling] = useState(false);
  const [selectedVersion, setSelectedVersion] = useState('');

  useEffect(() => {
    axios.get(`/api/client/servers/${serverId}/versions`)
      .then(res => {
        setVersions(res.data);
        if (res.data.length > 0) setSelectedVersion(res.data[0]);
      })
      .catch(err => toast.error("Failed to load versions"))
      .finally(() => setLoading(false));
  }, [serverId]);

  const handleUpdate = async () => {
    if (!selectedVersion) return;
    setInstalling(true);
    try {
      await axios.post(`/api/client/servers/${serverId}/version`, { version: selectedVersion });
      toast.success('Version updated and reinstall triggered!');
    } catch (e: any) {
      toast.error(e.response?.data?.message || 'Failed to update version');
    } finally {
      setInstalling(false);
    }
  };

  if (loading) return <div className="flex justify-center py-10"><Loader2 className="animate-spin text-orange-500" size={32} /></div>;

  return (
    <div className="space-y-6">
      <h3 className="text-3xl font-black tracking-tighter italic uppercase">Version Changer</h3>
      <div className="bg-neutral-900 border border-white/10 p-8 rounded-[2rem] space-y-6">
        <p className="text-neutral-400 text-sm">Select a new version for your server. This will update the startup variables and trigger a reinstall process.</p>
        <div className="space-y-4">
          <select 
            value={selectedVersion}
            onChange={(e) => setSelectedVersion(e.target.value)}
            className="w-full bg-neutral-800/50 border border-white/10 rounded-xl p-4 text-sm outline-none text-neutral-50"
          >
            {versions.map(v => <option key={v} value={v}>{v}</option>)}
          </select>
          <button 
            onClick={handleUpdate}
            disabled={installing}
            className="w-full py-4 bg-orange-500 text-black rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-orange-400 transition-all disabled:opacity-50"
          >
            {installing ? 'Updating...' : 'Update Version & Reinstall'}
          </button>
        </div>
      </div>
    </div>
  );
}

function PluginManager({ serverId }: { serverId: number }) {
  const [plugins, setPlugins] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [installingId, setInstallingId] = useState<string | null>(null);

  useEffect(() => {
    axios.get(`/api/client/servers/${serverId}/plugins`)
      .then(res => setPlugins(res.data))
      .catch(err => toast.error("Failed to load plugins"))
      .finally(() => setLoading(false));
  }, [serverId]);

  const handleInstall = async (pluginId: string) => {
    setInstallingId(pluginId);
    try {
      await axios.post(`/api/client/servers/${serverId}/plugins/install`, { plugin_id: pluginId });
      toast.success('Plugin installed successfully!');
    } catch (e: any) {
      toast.error(e.response?.data?.message || 'Failed to install plugin');
    } finally {
      setInstallingId(null);
    }
  };

  if (loading) return <div className="flex justify-center py-10"><Loader2 className="animate-spin text-orange-500" size={32} /></div>;

  return (
    <div className="space-y-6">
      <h3 className="text-3xl font-black tracking-tighter italic uppercase">Plugin Installer</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {plugins.map(plugin => (
          <div key={plugin.id} className="bg-neutral-900 border border-white/10 p-6 rounded-[2rem] space-y-4 flex flex-col">
            <div>
              <h4 className="font-bold text-lg text-neutral-50">{plugin.name}</h4>
              <p className="text-xs text-neutral-400">{plugin.desc || plugin.description}</p>
            </div>
            <button 
              onClick={() => handleInstall(plugin.id)}
              disabled={installingId === plugin.id}
              className="mt-auto w-full py-3 bg-orange-500 text-black rounded-xl font-black uppercase tracking-widest text-xs hover:bg-orange-400 transition-all disabled:opacity-50"
            >
              {installingId === plugin.id ? 'Installing...' : 'Install'}
            </button>
          </div>
        ))}
        {plugins.length === 0 && <p className="text-neutral-500 col-span-full text-center py-10">No plugins found.</p>}
      </div>
    </div>
  );
}

function ModInstaller({ serverId }: { serverId: number }) {
  const [mods, setMods] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [installingId, setInstallingId] = useState<string | null>(null);

  useEffect(() => {
    axios.get(`/api/client/servers/${serverId}/mods`)
      .then(res => setMods(res.data))
      .catch(err => toast.error("Failed to load mods"))
      .finally(() => setLoading(false));
  }, [serverId]);

  const handleInstall = async (modId: string) => {
    setInstallingId(modId);
    try {
      await axios.post(`/api/client/servers/${serverId}/mods/install`, { mod_id: modId });
      toast.success('Mod installed successfully!');
    } catch (e: any) {
      toast.error(e.response?.data?.message || 'Failed to install mod');
    } finally {
      setInstallingId(null);
    }
  };

  if (loading) return <div className="flex justify-center py-10"><Loader2 className="animate-spin text-orange-500" size={32} /></div>;

  return (
    <div className="space-y-6">
      <h3 className="text-3xl font-black tracking-tighter italic uppercase">Mod Installer</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {mods.map(mod => (
          <div key={mod.id} className="bg-neutral-900 border border-white/10 p-6 rounded-[2rem] space-y-4 flex flex-col">
            <div>
              <h4 className="font-bold text-lg text-neutral-50">{mod.title}</h4>
              <p className="text-xs text-neutral-400">{mod.description}</p>
            </div>
            <button 
              onClick={() => handleInstall(mod.id)}
              disabled={installingId === mod.id}
              className="mt-auto w-full py-3 bg-orange-500 text-black rounded-xl font-black uppercase tracking-widest text-xs hover:bg-orange-400 transition-all disabled:opacity-50"
            >
              {installingId === mod.id ? 'Installing...' : 'Install'}
            </button>
          </div>
        ))}
        {mods.length === 0 && <p className="text-neutral-500 col-span-full text-center py-10">No mods found.</p>}
      </div>
    </div>
  );
}

function ServerDashboard() {
  const { t } = useTranslation();
  const [activeSubTab, setActiveSubTab] = useState('console');
  const [ipBlurred, setIpBlurred] = useState(true);
  const [server, setServer] = useState<ServerData | null>(null);
  const [logs, setLogs] = useState<string[]>(["[SKA] Initializing server...", "[SKA] Loading world...", "[SKA] Server started on port 25565"]);

  useEffect(() => {
    // Mock fetch server details
    fetch('/api/servers').then(res => res.json()).then(data => setServer(data[0]));
  }, []);

  const handlePowerAction = async (signal: 'start' | 'stop' | 'restart') => {
    if (!server) return;
    try {
      const res = await fetch(`/api/client/servers/${server.id}/power`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ signal })
      });
      const data = await res.json();
      if (data.success) {
        toast.success(`Server ${signal} signal sent`);
        setLogs(prev => [...prev, `[SKA] Sending ${signal} signal to server...`]);
      } else {
        toast.error(data.error || `Failed to ${signal} server`);
      }
    } catch (err) {
      toast.error(`Error sending ${signal} signal`);
    }
  };

  if (!server) return <Loader />;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8">
      {/* Server Header */}
      <div className="flex items-center justify-between bg-neutral-900 border border-white/10 p-8 rounded-[2rem] relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <img src={server.bg_image} className="w-full h-full object-cover" />
        </div>
        <div className="relative z-10 flex items-center gap-6">
          <div className="w-20 h-20 rounded-2xl border border-white/10 overflow-hidden bg-neutral-800/50 backdrop-blur">
            <img src={server.custom_icon_image || server.icon_image} className="w-full h-full object-cover" />
          </div>
          <div>
            <h2 className="text-4xl font-black tracking-tighter uppercase italic text-white">{server.name}</h2>
            <div className="flex items-center gap-4 mt-2">
              <span className="flex items-center gap-2 text-xs font-bold text-neutral-400">
                <Globe size={14} /> 
                <span className={ipBlurred ? "blur-sm select-none" : ""}>192.168.1.100:25565</span>
                <button onClick={() => setIpBlurred(!ipBlurred)} className="hover:text-white transition-colors">
                  {ipBlurred ? <Eye size={14} /> : <EyeOff size={14} />}
                </button>
              </span>
              <span className="w-1 h-1 bg-white/10 rounded-full" />
              <span className="text-[10px] font-black uppercase tracking-widest text-green-500">Online</span>
            </div>
          </div>
        </div>
        <div className="relative z-10 flex gap-3">
          <button onClick={() => handlePowerAction('start')} className="px-6 py-3 bg-green-500/10 text-green-500 border border-green-500/20 rounded-xl font-black text-xs uppercase tracking-widest hover:bg-green-500 hover:text-black transition-all">Start</button>
          <button onClick={() => handlePowerAction('stop')} className="px-6 py-3 bg-red-500/10 text-red-500 border border-red-500/20 rounded-xl font-black text-xs uppercase tracking-widest hover:bg-red-500 hover:text-black transition-all">Stop</button>
          <button onClick={() => handlePowerAction('restart')} className="px-6 py-3 bg-orange-500 text-black rounded-xl font-black text-xs uppercase tracking-widest hover:bg-orange-400 transition-all">Restart</button>
        </div>
      </div>

      {/* Sub Navigation */}
      <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
        <SubNavItem active={activeSubTab === 'console'} onClick={() => setActiveSubTab('console')} icon={<Terminal size={16} />} label="Console" />
        <SubNavItem active={activeSubTab === 'economy'} onClick={() => setActiveSubTab('economy')} icon={<Coins size={16} />} label="Economy & AFK" />
        <SubNavItem active={activeSubTab === 'players'} onClick={() => setActiveSubTab('players')} icon={<Users size={16} />} label="Players" />
        <SubNavItem active={activeSubTab === 'network'} onClick={() => setActiveSubTab('network')} icon={<Globe size={16} />} label="Network & Domains" />
        <SubNavItem active={activeSubTab === 'visuals'} onClick={() => setActiveSubTab('visuals')} icon={<Settings size={16} />} label="Visuals" />
        <SubNavItem active={activeSubTab === 'management'} onClick={() => setActiveSubTab('management')} icon={<Zap size={16} />} label="Management" />
        <SubNavItem active={activeSubTab === 'software'} onClick={() => setActiveSubTab('software')} icon={<Database size={16} />} label="Version Changer" />
        <SubNavItem active={activeSubTab === 'plugins'} onClick={() => setActiveSubTab('plugins')} icon={<Puzzle size={16} />} label="Plugins" />
        <SubNavItem active={activeSubTab === 'mods'} onClick={() => setActiveSubTab('mods')} icon={<Database size={16} />} label="Mods" />
        <SubNavItem active={activeSubTab === 'logs'} onClick={() => setActiveSubTab('logs')} icon={<FileText size={16} />} label="Logs" />
      </div>

      <AnimatePresence mode="wait">
        {activeSubTab === 'console' && (
          <motion.div key="console" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-6">
            <div className="bg-black border border-white/10 rounded-2xl p-6 font-mono text-sm h-96 overflow-y-auto space-y-1 scrollbar-thin scrollbar-thumb-white/10">
              {logs.map((log, i) => (
                <div key={i} className="flex gap-4">
                  <span className="text-white/20">[{new Date().toLocaleTimeString()}]</span>
                  <span className="text-white/80">{log}</span>
                </div>
              ))}
              <div className="flex gap-4 animate-pulse">
                <span className="text-orange-500 tracking-widest">_</span>
              </div>
            </div>
            <div className="relative">
              <input 
                type="text" 
                placeholder="Type a command..." 
                className="w-full bg-neutral-900 border border-white/10 rounded-xl py-4 px-6 text-sm focus:border-orange-500 outline-none transition-all"
              />
              <button className="absolute right-4 top-1/2 -translate-y-1/2 text-orange-500 font-black text-xs uppercase tracking-widest">Send</button>
            </div>
          </motion.div>
        )}

        {activeSubTab === 'economy' && (
          <motion.div key="economy" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* AFK Rewards Zone */}
            <div className="bg-neutral-900 border border-white/10 p-8 rounded-[2rem] space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-2xl font-black tracking-tighter uppercase italic text-neutral-50">AFK Rewards Zone</h3>
                <div className="w-12 h-12 bg-orange-500/10 rounded-2xl flex items-center justify-center text-orange-500"><Clock size={24} /></div>
              </div>
              <div className="flex flex-col items-center py-8 gap-4">
                <div className="text-6xl font-black tracking-tighter text-orange-500">00:45:12</div>
                <p className="text-neutral-400 text-xs uppercase tracking-widest font-bold">Current Session Time</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white/5 p-4 rounded-2xl border border-white/5">
                  <p className="text-[10px] text-white/30 uppercase font-bold mb-1">Coins Earned</p>
                  <p className="text-xl font-black">12.45</p>
                </div>
                <div className="bg-white/5 p-4 rounded-2xl border border-white/5">
                  <p className="text-[10px] text-white/30 uppercase font-bold mb-1">Multiplier</p>
                  <p className="text-xl font-black text-green-500">1.5x</p>
                </div>
              </div>
              <button className="w-full py-4 bg-orange-500 text-black rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-orange-400 transition-all">Claim Rewards</button>
            </div>

            {/* Resource Manager */}
            <div className="bg-neutral-900 border border-white/10 p-8 rounded-[2rem] space-y-8">
              <div className="flex items-center justify-between">
                <h3 className="text-2xl font-black tracking-tighter uppercase italic">{t('dashboard.resource_manager')}</h3>
                <div className="w-12 h-12 bg-blue-500/10 rounded-2xl flex items-center justify-center text-blue-500"><Zap size={24} /></div>
              </div>
              <div className="space-y-6">
                <ResourceProgress label="RAM Usage" current={920} limit={1024} unit="MB" />
                <ResourceProgress label="CPU Usage" current={85} limit={100} unit="%" />
                <ResourceProgress label="Disk Usage" current={4500} limit={5120} unit="MB" />
              </div>
              <div className="p-4 bg-orange-500/10 border border-orange-500/20 rounded-2xl flex items-center gap-4">
                <AlertTriangle className="text-orange-500 animate-bounce" size={24} />
                <div>
                  <p className="text-xs font-black uppercase tracking-widest text-orange-500">Resource Alert</p>
                  <p className="text-[10px] text-white/60">RAM usage is near 90% limit. Consider upgrading.</p>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {activeSubTab === 'players' && (
          <motion.div key="players" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-8">
            <div className="flex items-center justify-between">
              <h3 className="text-3xl font-black tracking-tighter italic uppercase">Player Manager</h3>
              <div className="flex items-center gap-2 bg-white/5 px-4 py-2 rounded-xl border border-white/10">
                <Users size={16} className="text-neutral-500" />
                <span className="text-xs font-bold text-neutral-50">12 / 50 Online</span>
              </div>
            </div>
            <div className="bg-neutral-900 border border-white/10 rounded-[2rem] overflow-hidden">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-white/5 text-[10px] font-black uppercase tracking-widest text-neutral-400">
                    <th className="px-8 py-4">Player</th>
                    <th className="px-8 py-4">Status</th>
                    <th className="px-8 py-4">Ping</th>
                    <th className="px-8 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  <PlayerRow name="SDGAMER" status="Online" ping="24ms" onKick={() => {}} onBan={() => {}} />
                  <PlayerRow name="SkaHost" status="Online" ping="45ms" onKick={() => {}} onBan={() => {}} />
                  <PlayerRow name="Guest_123" status="Online" ping="120ms" onKick={() => {}} onBan={() => {}} />
                </tbody>
              </table>
            </div>
          </motion.div>
        )}

        {activeSubTab === 'network' && (
          <motion.div key="network" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Cloudflared Subdomains */}
            <div className="bg-neutral-900 border border-white/10 p-8 rounded-[2rem] space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-2xl font-black tracking-tighter uppercase italic text-neutral-50">Subdomains</h3>
                <div className="w-12 h-12 bg-blue-500/10 rounded-2xl flex items-center justify-center text-blue-500"><LinkIcon size={24} /></div>
              </div>
              <p className="text-xs text-neutral-400">Powered by Cloudflared Tunneling</p>
              <div className="flex gap-2">
                <input 
                  type="text" 
                  placeholder="myserver" 
                  className="flex-1 bg-neutral-800/50 border border-white/10 rounded-xl px-4 py-3 text-sm focus:border-orange-500 outline-none text-neutral-50"
                />
                <div className="bg-neutral-800/50 border border-white/10 rounded-xl px-4 py-3 text-sm text-neutral-400 flex items-center">.skahosting.com</div>
              </div>
              <button className="w-full py-4 bg-white text-black rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-orange-500 transition-all">Create Subdomain</button>
            </div>

            {/* Server Splitter */}
            <div className="bg-neutral-900 border border-white/10 p-8 rounded-[2rem] space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-2xl font-black tracking-tighter uppercase italic text-neutral-50">Server Splitter</h3>
                <div className="w-12 h-12 bg-purple-500/10 rounded-2xl flex items-center justify-center text-purple-500"><Scissors size={24} /></div>
              </div>
              <p className="text-xs text-neutral-400">Split your resources into a new child server.</p>
              <div className="space-y-4">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-neutral-50">RAM Allocation</span>
                  <span className="text-orange-500">512MB</span>
                </div>
                <input type="range" className="w-full accent-orange-500" />
              </div>
              <button className="w-full py-4 bg-neutral-800/50 border border-white/10 text-neutral-50 rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-white/10 transition-all">Initialize Split</button>
            </div>
          </motion.div>
        )}

        {activeSubTab === 'visuals' && (
          <motion.div key="visuals" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-neutral-900 border border-white/10 p-8 rounded-[2rem] space-y-6">
              <h3 className="text-2xl font-black tracking-tighter uppercase italic">Server Visuals</h3>
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-white/30 ml-2">Custom Background</label>
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      value={server.bg_image} 
                      onChange={(e) => setServer({...server, bg_image: e.target.value})}
                      className="flex-1 bg-white/5 border border-white/10 rounded-xl p-4 text-sm outline-none focus:border-orange-500/50"
                      placeholder="https://..."
                    />
                    <label className="p-4 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-all cursor-pointer">
                      <Upload size={18} />
                      <input 
                        type="file" 
                        className="hidden" 
                        accept="image/*"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const reader = new FileReader();
                            reader.onloadend = () => {
                              setServer({...server, bg_image: reader.result as string});
                            };
                            reader.readAsDataURL(file);
                          }
                        }}
                      />
                    </label>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-white/30 ml-2">Server Icon</label>
                  <div className="flex items-center gap-6">
                    <div className="w-20 h-20 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center overflow-hidden">
                      <img src={server.custom_icon_image || server.icon_image} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    </div>
                    <div className="flex-1 space-y-2">
                      <div className="flex gap-2">
                        <input 
                          type="text" 
                          value={server.custom_icon_image || ''} 
                          onChange={(e) => setServer({...server, custom_icon_image: e.target.value})}
                          className="flex-1 bg-white/5 border border-white/10 rounded-xl p-3 text-xs outline-none focus:border-orange-500/50"
                          placeholder="Icon URL (e.g. https://...)"
                        />
                        <label className="p-3 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-all cursor-pointer">
                          <Upload size={14} />
                          <input 
                            type="file" 
                            className="hidden" 
                            accept="image/*"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                const reader = new FileReader();
                                reader.onloadend = () => {
                                  setServer({...server, custom_icon_image: reader.result as string});
                                };
                                reader.readAsDataURL(file);
                              }
                            }}
                          />
                        </label>
                      </div>
                      <p className="text-[10px] text-white/30 italic">Upload an image or paste a URL to override the default egg icon.</p>
                    </div>
                  </div>
                </div>
                <button 
                  onClick={async () => {
                    try {
                      const response = await fetch(`/api/servers/${server.id}/visuals`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                          bg_image: server.bg_image,
                          custom_icon_image: server.custom_icon_image
                        })
                      });
                      if (response.ok) {
                        alert('Visual settings saved successfully!');
                      } else {
                        alert('Failed to save visual settings.');
                      }
                    } catch (error) {
                      console.error('Error saving visuals:', error);
                      alert('An error occurred while saving.');
                    }
                  }}
                  className="w-full py-4 bg-orange-500 text-black rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-orange-400 transition-all"
                >
                  Save Visuals
                </button>
              </div>
            </div>

            <div className="bg-neutral-900 border border-white/10 p-8 rounded-[2rem] space-y-6">
              <h3 className="text-2xl font-black tracking-tighter uppercase italic text-neutral-50">Console Preferences</h3>
              <div className="flex items-center justify-between p-6 bg-white/5 border border-white/10 rounded-3xl">
                <div>
                  <h4 className="font-bold text-neutral-50">Server IP Blur</h4>
                  <p className="text-xs text-neutral-400">Hide your server IP in the dashboard</p>
                </div>
                <button 
                  onClick={() => setIpBlurred(!ipBlurred)}
                  className={`w-12 h-6 rounded-full transition-colors relative ${ipBlurred ? 'bg-orange-500' : 'bg-white/10'}`}
                >
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${ipBlurred ? 'left-7' : 'left-1'}`} />
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {activeSubTab === 'management' && (
          <motion.div key="management" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-12">
            {/* Conditional Tools based on Software Type */}
            <div className="space-y-6">
              <h3 className="text-2xl font-black tracking-tighter uppercase italic flex items-center gap-3">
                Software Specific Tools
                <span className="text-[10px] font-mono bg-orange-500/10 px-2 py-1 rounded text-orange-500 uppercase tracking-widest not-italic">{server.software_type}</span>
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {server.software_type === 'bedrock' && (
                  <ManagementCard icon={<Plus size={24} />} title="Addon Installer" description="Browse and install Bedrock addons and behavior packs." onClick={() => toast.info("Addon Installer opening...")} />
                )}
                
                {server.software_type === 'java' && (
                  <>
                    <ManagementCard icon={<Database size={24} />} title="Mod Installer" description="Browse Modrinth & CurseForge for Fabric, Forge, or Quilt mods." onClick={() => setActiveSubTab('mods')} />
                    <ManagementCard icon={<Zap size={24} />} title="Plugin Manager" description="Install Spigot, Paper, or BungeeCord plugins instantly." onClick={() => setActiveSubTab('plugins')} />
                  </>
                )}
                
                {server.software_type === 'pocketmine' && (
                  <ManagementCard icon={<Zap size={24} />} title="Pocketmine Plugins" description="Access the official Pocketmine-MP plugin repository." onClick={() => toast.info("Pocketmine Plugins opening...")} />
                )}
              </div>
            </div>

            {/* Universal Tools */}
            <div className="space-y-6">
              <h3 className="text-2xl font-black tracking-tighter uppercase italic">Universal Tools</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <ManagementCard icon={<Folder size={24} />} title="File Manager" description="Manage your server files directly from the browser." onClick={() => toast.info("File Manager opening...")} />
                <ManagementCard icon={<Terminal size={24} />} title="SFTP Details" description="View credentials to connect via SFTP." onClick={() => toast.info("SFTP Details: sftp.skahosting.com:2022")} />
                <ManagementCard icon={<Scissors size={24} />} title="Egg Changer" description="Switch between different server types and game versions." onClick={() => toast.info("Egg Changer opening...")} />
                <ManagementCard icon={<Activity size={24} />} title="Version Changer" description="Update or downgrade your server software version." onClick={() => setActiveSubTab('software')} />
                <ManagementCard icon={<ShieldCheck size={24} />} title="Votifier Tester" description="Test your server voting connection and rewards." onClick={() => toast.info("Votifier Tester opening...")} />
                <ManagementCard icon={<HardDrive size={24} />} title="Vanilla Tweaks" description="Apply custom data packs and resource tweaks." onClick={() => toast.info("Vanilla Tweaks opening...")} />
                <ManagementCard icon={<Database size={24} />} title="Backup System" description="Create manual backups of your entire server." onClick={() => toast.info("Backup System opening...")} />
                <ManagementCard icon={<Clock size={24} />} title="Auto Backup" description="Configure automated daily or weekly backups." onClick={() => toast.info("Auto Backup opening...")} />
              </div>
            </div>
          </motion.div>
        )}

        {activeSubTab === 'software' && (
          <motion.div key="software" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
            <VersionChanger serverId={server.id} />
          </motion.div>
        )}

        {activeSubTab === 'plugins' && (
          <motion.div key="plugins" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
            <PluginManager serverId={server.id} />
          </motion.div>
        )}

        {activeSubTab === 'mods' && (
          <motion.div key="mods" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
            <ModInstaller serverId={server.id} />
          </motion.div>
        )}

        {activeSubTab === 'logs' && (
          <motion.div key="logs" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-3xl font-black tracking-tighter italic uppercase">Server Logs</h3>
              <div className="flex gap-3">
                <button 
                  onClick={() => {
                    const logText = logs.join('\n');
                    fetch('https://api.mclo.gs/1/log', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                      body: new URLSearchParams({ content: logText })
                    })
                    .then(res => res.json())
                    .then(data => {
                      if (data.success) window.open(data.url, '_blank');
                    });
                  }}
                  className="flex items-center gap-2 px-6 py-3 bg-orange-500 text-black rounded-xl font-black text-xs uppercase tracking-widest hover:bg-orange-400 transition-all"
                >
                  <Share2 size={16} /> Share to McLogs
                </button>
              </div>
            </div>
            <div className="bg-black border border-white/10 rounded-2xl p-8 font-mono text-sm h-[500px] overflow-y-auto scrollbar-thin scrollbar-thumb-white/10">
              <pre className="text-white/60 whitespace-pre-wrap">
                {logs.join('\n')}
              </pre>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function SubNavItem({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active?: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`flex items-center gap-2 px-6 py-3 rounded-xl transition-all whitespace-nowrap border ${
        active ? 'bg-orange-500 text-black border-orange-500 font-black' : 'bg-neutral-800/50 text-neutral-400 border-white/5 hover:border-white/20 hover:text-white'
      }`}
    >
      {icon}
      <span className="text-[10px] uppercase tracking-widest">{label}</span>
    </button>
  );
}

function ResourceProgress({ label, current, limit, unit }: { label: string, current: number, limit: number, unit: string }) {
  const percent = (current / limit) * 100;
  const isAlert = percent > 90;
  return (
    <div className="space-y-2">
      <div className="flex justify-between text-[10px] font-black uppercase tracking-widest">
        <span className="text-neutral-500">{label}</span>
        <span className={isAlert ? "text-orange-500" : "text-neutral-50"}>{current}{unit} / {limit}{unit}</span>
      </div>
      <div className="h-2 bg-white/5 rounded-full overflow-hidden">
        <motion.div 
          initial={{ width: 0 }} 
          animate={{ width: `${percent}%` }} 
          className={`h-full rounded-full ${isAlert ? "bg-orange-500" : "bg-blue-500"}`} 
        />
      </div>
    </div>
  );
}

function PlayerRow({ name, status, ping, onKick, onBan }: { name: string, status: string, ping: string, onKick: () => void, onBan: () => void }) {
  return (
    <tr className="group hover:bg-white/[0.02] transition-colors">
      <td className="px-8 py-6">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center font-black text-orange-500">{name[0]}</div>
          <span className="font-bold">{name}</span>
        </div>
      </td>
      <td className="px-8 py-6">
        <span className="px-3 py-1 bg-green-500/10 text-green-500 text-[10px] font-black uppercase rounded-full border border-green-500/20">{status}</span>
      </td>
      <td className="px-8 py-6 text-xs font-mono text-neutral-500">{ping}</td>
      <td className="px-8 py-6 text-right">
        <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
          <button onClick={onKick} className="p-2 hover:bg-white/10 rounded-lg text-neutral-500 hover:text-white transition-colors" title="Kick Player"><UserMinus size={16} /></button>
          <button onClick={onBan} className="p-2 hover:bg-red-500/20 rounded-lg text-neutral-500 hover:text-red-500 transition-colors" title="Ban Player"><UserX size={16} /></button>
        </div>
      </td>
    </tr>
  );
}

function ServersContent() {
  const [servers, setServers] = useState<ServerData[]>([]);
  useEffect(() => {
    fetch('/api/servers').then(res => res.json()).then(setServers);
  }, []);

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-black tracking-tighter italic uppercase">My Servers</h2>
        <button className="bg-white text-black px-6 py-3 rounded-xl font-black uppercase tracking-widest text-xs hover:bg-orange-500 transition-all">Create New</button>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {servers.map(server => (
          <ServerCard key={server.id} server={server} onApprove={() => {}} />
        ))}
      </div>
    </motion.div>
  );
}

function RedeemCodeManagement() {
  const [codes, setCodes] = useState<any[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [newCode, setNewCode] = useState({
    code: '',
    reward_coins: 0,
    max_uses: 0,
    expires_at: ''
  });
  
  const fetchCodes = () => {
    fetch('/api/admin/redeem-codes').then(res => res.json()).then(setCodes);
  };

  useEffect(() => {
    fetchCodes();
  }, []);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (newCode.code && newCode.reward_coins > 0 && newCode.max_uses > 0) {
      fetch('/api/admin/redeem-codes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...newCode,
          code: newCode.code.toUpperCase(),
          expires_at: newCode.expires_at ? new Date(newCode.expires_at).toISOString() : null
        })
      })
      .then(res => res.json())
      .then(() => {
        fetchCodes();
        setShowForm(false);
        setNewCode({ code: '', reward_coins: 0, max_uses: 0, expires_at: '' });
      });
    }
  };

  const deleteCode = (id: number) => {
    if (confirm("Delete this code?")) {
      fetch(`/api/admin/redeem-codes/${id}`, { method: 'DELETE' }).then(() => fetchCodes());
    }
  };

  return (
    <div className="space-y-12">
      <div className="flex items-center justify-between">
        <h2 className="text-4xl font-black tracking-tighter italic uppercase">Redeem Codes</h2>
        <button 
          onClick={() => setShowForm(!showForm)} 
          className="bg-orange-500 text-black px-6 py-3 rounded-xl font-black uppercase tracking-widest text-xs hover:bg-orange-400 transition-all flex items-center gap-2"
        >
          {showForm ? <X size={18} /> : <Plus size={18} />} {showForm ? "Cancel" : "Generate Code"}
        </button>
      </div>

      <AnimatePresence>
        {showForm && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <form onSubmit={handleCreate} className="bg-white/5 border border-white/10 p-8 rounded-[2rem] grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest opacity-50">Code String</label>
                <input 
                  type="text" 
                  value={newCode.code}
                  onChange={(e) => setNewCode({...newCode, code: e.target.value})}
                  placeholder="WELCOME10"
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-sm font-bold outline-none focus:border-orange-500/50"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest opacity-50">Reward Coins</label>
                <input 
                  type="number" 
                  value={newCode.reward_coins}
                  onChange={(e) => setNewCode({...newCode, reward_coins: parseInt(e.target.value)})}
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-sm font-bold outline-none focus:border-orange-500/50"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest opacity-50">Max Uses</label>
                <input 
                  type="number" 
                  value={newCode.max_uses}
                  onChange={(e) => setNewCode({...newCode, max_uses: parseInt(e.target.value)})}
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-sm font-bold outline-none focus:border-orange-500/50"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest opacity-50">Expiry Date (Optional)</label>
                <div className="flex gap-2">
                  <input 
                    type="date" 
                    value={newCode.expires_at}
                    onChange={(e) => setNewCode({...newCode, expires_at: e.target.value})}
                    className="flex-1 bg-white/5 border border-white/10 rounded-xl p-4 text-sm font-bold outline-none focus:border-orange-500/50"
                  />
                  <button type="submit" className="p-4 bg-orange-500 text-black rounded-xl hover:bg-orange-600 transition-all">
                    <Plus size={18} />
                  </button>
                </div>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="bg-neutral-900 border border-white/10 rounded-[2rem] overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-white/5 text-[10px] font-black uppercase tracking-widest text-neutral-400">
              <th className="px-8 py-4">Code</th>
              <th className="px-8 py-4">Reward</th>
              <th className="px-8 py-4">Uses</th>
              <th className="px-8 py-4">Expires</th>
              <th className="px-8 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {codes.map(c => (
              <tr key={c.id} className="hover:bg-white/[0.02] transition-colors">
                <td className="px-8 py-4 font-black text-orange-500">{c.code}</td>
                <td className="px-8 py-4 font-bold">{c.reward_coins} Coins</td>
                <td className="px-8 py-4 text-xs font-mono">{c.current_uses} / {c.max_uses}</td>
                <td className="px-8 py-4 text-xs text-neutral-400">{c.expires_at ? new Date(c.expires_at).toLocaleDateString() : 'Never'}</td>
                <td className="px-8 py-4 text-right">
                  <button onClick={() => deleteCode(c.id)} className="text-red-500 hover:text-red-400 transition-colors">
                    <X size={18} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function TicketsContent() {
  const { user } = useContext(AuthContext)!;
  const [tickets, setTickets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [newSubject, setNewSubject] = useState('');
  const [newMessage, setNewMessage] = useState('');
  const [activeTicket, setActiveTicket] = useState<any | null>(null);
  const [replyMessage, setReplyMessage] = useState('');

  useEffect(() => {
    fetch('/api/tickets').then(res => res.json()).then(data => {
      setTickets(data);
      setLoading(false);
    });
  }, []);

  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubject || !newMessage) return;
    const res = await fetch('/api/tickets', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ subject: newSubject, message: newMessage })
    });
    const data = await res.json();
    setTickets([...tickets, data]);
    setNewSubject('');
    setNewMessage('');
    toast.success("Ticket created successfully");
  };

  const handleReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyMessage || !activeTicket) return;
    const res = await fetch(`/api/tickets/${activeTicket.id}/reply`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: replyMessage })
    });
    const data = await res.json();
    setTickets(tickets.map(t => t.id === data.id ? data : t));
    setActiveTicket(data);
    setReplyMessage('');
  };

  if (loading) return <Loader />;

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
      <h2 className="text-3xl font-black tracking-tighter italic uppercase">Support Tickets</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-neutral-900 border border-white/10 p-6 rounded-[2rem]">
            <h3 className="text-xl font-bold mb-4">Create Ticket</h3>
            <form onSubmit={handleCreateTicket} className="space-y-4">
              <input 
                type="text" 
                value={newSubject}
                onChange={e => setNewSubject(e.target.value)}
                placeholder="Subject"
                className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-sm outline-none focus:border-orange-500/50"
                required
              />
              <textarea 
                value={newMessage}
                onChange={e => setNewMessage(e.target.value)}
                placeholder="Describe your issue..."
                className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-sm outline-none focus:border-orange-500/50 min-h-[120px]"
                required
              />
              <button type="submit" className="w-full py-3 bg-orange-500 text-black font-bold rounded-xl hover:bg-orange-400 transition-colors">
                Submit Ticket
              </button>
            </form>
          </div>

          <div className="space-y-2">
            <h3 className="text-sm font-bold uppercase tracking-widest text-neutral-500 mb-4">Your Tickets</h3>
            {tickets.map(ticket => (
              <div 
                key={ticket.id} 
                onClick={() => setActiveTicket(ticket)}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${activeTicket?.id === ticket.id ? 'bg-white/10 border-orange-500' : 'bg-neutral-900 border-white/10 hover:border-white/30'}`}
              >
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-bold text-sm truncate pr-4">{ticket.subject}</h4>
                  <span className={`text-[10px] font-black uppercase px-2 py-1 rounded ${ticket.status === 'open' ? 'bg-green-500/20 text-green-500' : 'bg-white/10 text-white/50'}`}>
                    {ticket.status}
                  </span>
                </div>
                <p className="text-xs text-neutral-400 truncate">
                  {ticket.messages[ticket.messages.length - 1]?.text}
                </p>
              </div>
            ))}
            {tickets.length === 0 && (
              <p className="text-sm text-neutral-500 text-center py-4">No tickets found.</p>
            )}
          </div>
        </div>

        <div className="lg:col-span-2">
          {activeTicket ? (
            <div className="bg-neutral-900 border border-white/10 rounded-[2rem] flex flex-col h-[600px]">
              <div className="p-6 border-b border-white/10">
                <h3 className="text-xl font-bold">{activeTicket.subject}</h3>
                <p className="text-xs text-neutral-400 mt-1">Ticket #{activeTicket.id}</p>
              </div>
              
              <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
                {activeTicket.messages.map((msg: any, i: number) => (
                  <div key={i} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] p-4 rounded-2xl ${msg.sender === 'user' ? 'bg-orange-500 text-black rounded-tr-sm' : 'bg-white/10 text-white rounded-tl-sm'}`}>
                      <p className="text-sm">{msg.text}</p>
                      <p className={`text-[10px] mt-2 opacity-50 ${msg.sender === 'user' ? 'text-black' : 'text-white'}`}>
                        {new Date(msg.timestamp).toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="p-6 border-t border-white/10">
                <form onSubmit={handleReply} className="flex gap-4">
                  <input 
                    type="text" 
                    value={replyMessage}
                    onChange={e => setReplyMessage(e.target.value)}
                    placeholder="Type your reply..."
                    className="flex-1 bg-white/5 border border-white/10 rounded-xl p-4 text-sm outline-none focus:border-orange-500/50"
                  />
                  <button type="submit" className="px-8 py-4 bg-orange-500 text-black font-bold rounded-xl hover:bg-orange-400 transition-colors">
                    Reply
                  </button>
                </form>
              </div>
            </div>
          ) : (
            <div className="bg-neutral-900 border border-white/10 rounded-[2rem] h-[600px] flex flex-col items-center justify-center text-neutral-500">
              <MessageSquare size={48} className="mb-4 opacity-50" />
              <p>Select a ticket to view details</p>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}

function StoreContent() {
  const { user, setUser } = useContext(AuthContext)!;
  const [redeemCode, setRedeemCode] = useState('');
  const [redeemLoading, setRedeemLoading] = useState(false);

  const handleRedeem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!redeemCode) return;
    setRedeemLoading(true);
    try {
      const res = await axios.post('/api/client/store/redeem', { code: redeemCode });
      const data = res.data;
      if (data.success) {
        setUser(data.user);
        toast.success(`Successfully redeemed ${data.reward} coins!`);
        setRedeemCode('');
      } else {
        toast.error(data.message || "Invalid or expired code.");
      }
    } catch (err: any) {
      const errorMsg = err.response?.data?.message || "Redemption failed. Please try again.";
      toast.error(errorMsg);
    } finally {
      setRedeemLoading(false);
    }
  };

  const handleUpgrade = (type: string, amount: number, cost: number) => {
    fetch('/api/economy/upgrade', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type, amount, cost })
    })
    .then(res => res.json())
    .then(data => {
      if (data.success) setUser(data.user);
      else alert(data.message);
    });
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-12">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Redeem Section */}
        <div className="lg:col-span-1 bg-neutral-900 border border-white/10 p-8 rounded-[2.5rem] space-y-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500/10 blur-3xl rounded-full -mr-16 -mt-16" />
          <h3 className="text-2xl font-black tracking-tighter uppercase italic text-neutral-50">Redeem Code</h3>
          <p className="text-xs text-neutral-400 leading-relaxed">Have a promotional code? Enter it below to claim your rewards instantly.</p>
          <form onSubmit={handleRedeem} className="space-y-4">
            <input 
              type="text" 
              value={redeemCode}
              onChange={(e) => setRedeemCode(e.target.value.toUpperCase())}
              placeholder="ENTER CODE HERE"
              className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-center font-black tracking-widest text-orange-500 outline-none focus:border-orange-500/50 transition-all"
            />
            <button 
              disabled={redeemLoading}
              className="w-full py-4 bg-white text-black rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-orange-500 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {redeemLoading ? <Loader2 className="animate-spin" size={16} /> : "Claim Reward"}
            </button>
          </form>
        </div>

        <div className="lg:col-span-2 space-y-8">
          <h2 className="text-3xl font-black tracking-tighter italic uppercase">Coin Store</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <StoreItem icon={<Server className="text-blue-500" />} label="Server Slot" cost={50} onBuy={() => handleUpgrade('servers', 1, 50)} />
            <StoreItem icon={<Database className="text-purple-500" />} label="1GB RAM" cost={20} onBuy={() => handleUpgrade('ram', 1024, 20)} />
            <StoreItem icon={<Cpu className="text-orange-500" />} label="50% CPU" cost={15} onBuy={() => handleUpgrade('cpu', 50, 15)} />
            <StoreItem icon={<HardDrive className="text-green-500" />} label="5GB Disk" cost={10} onBuy={() => handleUpgrade('disk', 5120, 10)} />
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function SoftwareContent() {
  const [activeModal, setActiveModal] = useState<string | null>(null);

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
      <h2 className="text-3xl font-black tracking-tighter italic uppercase">Software Center</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-neutral-900 border border-white/10 p-8 rounded-3xl flex flex-col items-center text-center gap-4">
          <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center text-blue-500"><Database size={32} /></div>
          <h3 className="text-xl font-bold text-neutral-50">Mod Installers</h3>
          <p className="text-sm text-neutral-400">One-click installation for popular modpacks and frameworks.</p>
          <button onClick={() => setActiveModal('mods')} className="mt-4 w-full py-3 bg-white/5 hover:bg-white/10 rounded-xl text-xs font-bold uppercase tracking-widest transition-all text-neutral-50">Browse Mods</button>
        </div>
        <div className="bg-neutral-900 border border-white/10 p-8 rounded-3xl flex flex-col items-center text-center gap-4">
          <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center text-green-500"><Plus size={32} /></div>
          <h3 className="text-xl font-bold text-neutral-50">Plugin Manager</h3>
          <p className="text-sm text-neutral-400">Manage your Spigot, Bukkit, or BungeeCord plugins with ease.</p>
          <button onClick={() => setActiveModal('plugins')} className="mt-4 w-full py-3 bg-white/5 hover:bg-white/10 rounded-xl text-xs font-bold uppercase tracking-widest transition-all text-neutral-50">Manage Plugins</button>
        </div>
        <div className="bg-neutral-900 border border-white/10 p-8 rounded-3xl flex flex-col items-center text-center gap-4">
          <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center text-orange-500"><Activity size={32} /></div>
          <h3 className="text-xl font-bold text-neutral-50">Addon Store</h3>
          <p className="text-sm text-neutral-400">Extend your server functionality with custom SKA addons.</p>
          <button onClick={() => setActiveModal('addons')} className="mt-4 w-full py-3 bg-white/5 hover:bg-white/10 rounded-xl text-xs font-bold uppercase tracking-widest transition-all text-neutral-50">View Addons</button>
        </div>
      </div>

      <AnimatePresence>
        {activeModal && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="bg-neutral-900 border border-white/10 p-8 rounded-[2rem] max-w-2xl w-full">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-black italic uppercase">
                  {activeModal === 'mods' ? 'Mod Installers' : activeModal === 'plugins' ? 'Plugin Manager' : 'Addon Store'}
                </h3>
                <button onClick={() => setActiveModal(null)} className="text-white/50 hover:text-white"><X size={24} /></button>
              </div>
              <div className="space-y-4 text-neutral-400">
                <p>Configuration panel for {activeModal}. Select items to install or manage.</p>
                <div className="grid grid-cols-2 gap-4">
                  {[1, 2, 3, 4].map(i => (
                    <div key={i} className="p-4 bg-white/5 rounded-xl border border-white/5 flex justify-between items-center">
                      <span>Item {i}</span>
                      <button className="px-3 py-1 bg-orange-500 text-black text-xs font-bold rounded-lg">Install</button>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function ExtensionsContent() {
  const [extensions, setExtensions] = useState<any[]>([]);
  useEffect(() => {
    fetch('/api/extensions').then(res => res.json()).then(setExtensions);
  }, []);

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
      <h2 className="text-3xl font-black tracking-tighter italic uppercase flex items-center gap-3">
        <Puzzle size={32} className="text-orange-500" />
        Blueprint Extensions
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {extensions.map(ext => (
          <div key={ext.id} className="bg-neutral-900 border border-white/10 p-8 rounded-3xl flex flex-col gap-4 hover:border-orange-500/30 transition-all group">
            <div className="w-12 h-12 bg-white/5 rounded-xl flex items-center justify-center text-orange-500 group-hover:scale-110 transition-transform">
              <Puzzle size={24} />
            </div>
            <div>
              <h3 className="text-xl font-bold text-neutral-50">{ext.name}</h3>
              <p className="text-[10px] font-mono text-neutral-500 uppercase tracking-widest mt-1">Version {ext.version}</p>
            </div>
            <p className="text-sm text-neutral-400">{ext.description}</p>
            <Link to={`/admin/extensions/${ext.identifier || ext.id}`} className="mt-auto w-full py-3 bg-white/5 hover:bg-white/10 rounded-xl text-xs font-bold uppercase tracking-widest transition-all text-center block">Open Extension</Link>
          </div>
        ))}
        {extensions.length === 0 && (
          <div className="col-span-full py-20 text-center space-y-4">
            <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mx-auto text-neutral-500">
              <Puzzle size={40} />
            </div>
            <p className="text-neutral-500 font-bold uppercase tracking-widest text-xs">No extensions detected</p>
          </div>
        )}
      </div>
    </motion.div>
  );
}

function SettingsContent() {
  const { settings } = useContext(AuthContext)!;
  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
      <h2 className="text-3xl font-black tracking-tighter italic uppercase">Dashboard Settings</h2>
      <div className="bg-neutral-900 border border-white/10 rounded-3xl p-8 max-w-2xl">
        <div className="space-y-6">
          <div className="flex items-center justify-between py-4 border-b border-white/5">
            <div>
              <p className="font-bold text-neutral-50">Dashboard Name</p>
              <p className="text-xs text-neutral-400">Change the visible name of your dashboard.</p>
            </div>
            <p className="text-orange-500 font-mono font-bold">{settings!.dashboard_name}</p>
          </div>
          <div className="flex items-center justify-between py-4 border-b border-white/5">
            <div>
              <p className="font-bold text-neutral-50">Discord Integration</p>
              <p className="text-xs text-neutral-400">Your linked Discord server for notifications.</p>
            </div>
            <a href={settings!.discord_link} className="text-blue-400 hover:underline text-xs">Linked</a>
          </div>
          <div className="flex items-center justify-between py-4">
            <div>
              <p className="font-bold text-neutral-50">Resource Upgrades</p>
              <p className="text-xs text-neutral-400">Allow users to purchase resource upgrades.</p>
            </div>
            <div className={`w-12 h-6 rounded-full p-1 transition-colors ${settings!.resource_upgrade_toggle ? 'bg-green-500' : 'bg-white/10'}`}>
              <div className={`w-4 h-4 bg-white rounded-full transition-transform ${settings!.resource_upgrade_toggle ? 'translate-x-6' : ''}`} />
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function StoreItem({ icon, label, cost, onBuy }: { icon: React.ReactNode, label: string, cost: number, onBuy: () => void }) {
  return (
    <div className="bg-neutral-900 border border-white/10 p-6 rounded-2xl flex flex-col items-center text-center gap-4 hover:border-orange-500/30 transition-all group">
      <div className="p-4 bg-white/5 rounded-2xl group-hover:scale-110 transition-transform">{icon}</div>
      <div>
        <h4 className="font-bold text-neutral-50">{label}</h4>
        <p className="text-xs text-neutral-400 mt-1">{cost} Coins</p>
      </div>
      <button onClick={onBuy} className="w-full py-2 bg-orange-500 text-black font-black text-[10px] uppercase tracking-widest rounded-lg hover:bg-orange-400 transition-colors">Purchase</button>
    </div>
  );
}

// --- Helper Components ---

function NavItem({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active?: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group ${
        active ? 'bg-orange-500 text-black font-bold shadow-lg shadow-orange-500/20' : 'text-neutral-400 hover:text-white hover:bg-white/10'
      }`}
    >
      <span className={`${active ? 'text-black' : 'text-neutral-500 group-hover:text-white'} transition-colors`}>
        {icon}
      </span>
      <span className="text-sm tracking-tight">{label}</span>
    </button>
  );
}

function StatCard({ icon, label, value, sub }: { icon: React.ReactNode, label: string, value: string, sub: string }) {
  const { t } = useTranslation();
  return (
    <div className="bg-neutral-900 border border-white/10 p-6 rounded-2xl hover:border-white/20 transition-colors group">
      <div className="flex items-center justify-between mb-4">
        <div className="p-2 bg-white/5 rounded-lg group-hover:scale-110 transition-transform">
          {icon}
        </div>
        <span className="text-[10px] font-mono text-neutral-500 uppercase tracking-tighter">{t('dashboard.realtime')}</span>
      </div>
      <p className="text-sm text-neutral-400 font-medium mb-1">{label}</p>
      <h3 className="text-3xl font-bold tracking-tighter mb-1 text-white">{value}</h3>
      <p className="text-xs text-neutral-500 font-mono">{sub}</p>
    </div>
  );
}

interface ServerCardProps {
  server: ServerData;
  onApprove: () => void;
  onClick?: () => void;
  key?: React.Key;
}

function ServerCard({ server, onApprove, onClick }: ServerCardProps) {
  return (
    <div 
      onClick={onClick}
      className={`relative group overflow-hidden rounded-2xl border border-white/10 bg-neutral-900 ${onClick ? 'cursor-pointer' : ''}`}
    >
      <div className="absolute inset-0 z-0">
        <img src={server.bg_image} className="w-full h-full object-cover opacity-20 group-hover:scale-110 transition-transform duration-700" referrerPolicy="no-referrer" />
        <div className="absolute inset-0 bg-gradient-to-t from-neutral-900 via-neutral-900/80 to-transparent" />
      </div>

      <div className="relative z-10 p-6 flex flex-col h-full">
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl border border-white/10 overflow-hidden bg-black/50 backdrop-blur">
              <img src={server.custom_icon_image || server.icon_image} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            </div>
            <div>
              <h3 className="font-bold text-lg leading-tight">{server.name}</h3>
              <div className="flex items-center gap-2 mt-1">
                <span className={`w-2 h-2 rounded-full ${
                  server.approval_status === 'approved' ? 'bg-green-500' : 
                  server.approval_status === 'pending' ? 'bg-yellow-500 animate-pulse' : 'bg-red-500'
                }`} />
                <span className="text-[10px] uppercase font-bold tracking-widest text-neutral-400">{server.approval_status}</span>
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            {server.approval_status === 'pending' && (
              <button 
                onClick={onApprove}
                className="px-3 py-1.5 bg-green-500 text-black text-[10px] font-black rounded-lg hover:bg-green-400 transition-colors"
              >
                APPROVE (ADMIN)
              </button>
            )}
            <button className="p-2 bg-white/5 hover:bg-white/10 rounded-lg transition-colors">
              <ExternalLink size={18} className="text-white/50" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 mt-auto">
          <div className="bg-neutral-800/50 backdrop-blur p-3 rounded-xl border border-white/5">
            <p className="text-[10px] text-neutral-500 uppercase font-bold mb-1">RAM</p>
            <p className="text-sm font-mono font-bold text-neutral-50">{server.resources.ram}MB</p>
          </div>
          <div className="bg-neutral-800/50 backdrop-blur p-3 rounded-xl border border-white/5">
            <p className="text-[10px] text-neutral-500 uppercase font-bold mb-1">CPU</p>
            <p className="text-sm font-mono font-bold text-neutral-50">{server.resources.cpu}%</p>
          </div>
          <div className="bg-neutral-800/50 backdrop-blur p-3 rounded-xl border border-white/5">
            <p className="text-[10px] text-neutral-500 uppercase font-bold mb-1">DISK</p>
            <p className="text-sm font-mono font-bold text-neutral-50">{server.resources.disk}MB</p>
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-4">
            {server.auto_backup && (
              <span className="flex items-center gap-1.5 text-[10px] font-bold text-blue-400 uppercase tracking-wider">
                <ShieldCheck size={12} /> Auto Backup
              </span>
            )}
          </div>
          <button className="text-xs font-bold text-orange-500 hover:underline">Manage Server</button>
        </div>
      </div>
    </div>
  );
}
