import { motion } from 'motion/react';
import { 
  Server, 
  Cpu, 
  HardDrive, 
  Activity, 
  Terminal, 
  Settings, 
  Database, 
  Globe, 
  Shield, 
  User, 
  LogOut, 
  Search, 
  Bell, 
  ChevronRight, 
  Play, 
  Square, 
  RefreshCw 
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import { cn } from './lib/utils';

const data = [
  { time: '00:00', cpu: 25, ram: 40 },
  { time: '04:00', cpu: 35, ram: 45 },
  { time: '08:00', cpu: 65, ram: 55 },
  { time: '12:00', cpu: 45, ram: 60 },
  { time: '16:00', cpu: 85, ram: 70 },
  { time: '20:00', cpu: 55, ram: 65 },
  { time: '23:59', cpu: 30, ram: 50 },
];

const servers = [
  { id: '1', name: 'Survival #1', status: 'online', cpu: '12%', ram: '2.4GB', disk: '15GB', ip: '192.168.1.10:25565' },
  { id: '2', name: 'Creative World', status: 'online', cpu: '5%', ram: '1.2GB', disk: '5GB', ip: '192.168.1.11:25566' },
  { id: '3', name: 'Bungee Proxy', status: 'online', cpu: '2%', ram: '0.5GB', disk: '1GB', ip: '192.168.1.12:25577' },
  { id: '4', name: 'Database Server', status: 'offline', cpu: '0%', ram: '0GB', disk: '50GB', ip: '192.168.1.13:3306' },
];

const SidebarItem = ({ icon: Icon, label, active = false }: { icon: any, label: string, active?: boolean }) => (
  <motion.div 
    whileHover={{ x: 4 }}
    className={cn(
      "flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer transition-all duration-300 group",
      active 
        ? "bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 shadow-[0_0_15px_rgba(99,102,241,0.2)]" 
        : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
    )}
  >
    <Icon size={20} className={cn(active ? "text-indigo-400" : "group-hover:text-indigo-400 transition-colors")} />
    <span className="font-medium text-sm">{label}</span>
    {active && <motion.div layoutId="active-indicator" className="ml-auto w-1.5 h-1.5 rounded-full bg-indigo-400 shadow-[0_0_8px_rgba(129,140,248,0.8)]" />}
  </motion.div>
);

const StatCard = ({ icon: Icon, label, value, color }: { icon: any, label: string, value: string, color: string }) => (
  <div className="bg-slate-900/40 backdrop-blur-xl border border-slate-800/50 rounded-2xl p-5 group hover:border-indigo-500/30 transition-all duration-500">
    <div className="flex items-center gap-4">
      <div className={cn("p-3 rounded-xl bg-opacity-10", color)}>
        <Icon size={24} className={color.replace('bg-', 'text-').replace('-10', '')} />
      </div>
      <div>
        <p className="text-slate-500 text-xs font-medium uppercase tracking-wider">{label}</p>
        <p className="text-2xl font-bold text-slate-100 mt-0.5">{value}</p>
      </div>
    </div>
  </div>
);

export default function NebulaTheme() {
  return (
    <div className="min-h-screen bg-[#0a0510] text-slate-200 font-sans selection:bg-indigo-500/30 overflow-hidden relative">
      {/* Background Atmosphere */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-indigo-900/20 blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-purple-900/20 blur-[120px]" />
        <div className="absolute top-[20%] right-[10%] w-[30%] h-[30%] rounded-full bg-blue-900/10 blur-[100px]" />
      </div>

      {/* Sidebar */}
      <aside className="fixed left-0 top-0 bottom-0 w-64 bg-slate-950/50 backdrop-blur-2xl border-r border-slate-800/50 z-50 flex flex-col p-6">
        <div className="flex items-center gap-3 mb-10 px-2">
          <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center shadow-[0_0_20px_rgba(79,70,229,0.5)]">
            <Globe className="text-white" size={24} />
          </div>
          <h1 className="text-xl font-bold tracking-tight bg-gradient-to-r from-white to-slate-400 bg-clip-text text-transparent">
            NEBULA<span className="text-indigo-500">.</span>
          </h1>
        </div>

        <nav className="flex-1 space-y-2">
          <p className="text-[10px] uppercase tracking-[0.2em] text-slate-500 font-bold mb-4 px-4">Main Menu</p>
          <SidebarItem icon={Activity} label="Dashboard" active />
          <SidebarItem icon={Server} label="Servers" />
          <SidebarItem icon={Database} label="Databases" />
          <SidebarItem icon={Shield} label="Security" />
          <SidebarItem icon={Terminal} label="Console" />
          
          <p className="text-[10px] uppercase tracking-[0.2em] text-slate-500 font-bold mt-8 mb-4 px-4">Management</p>
          <SidebarItem icon={Settings} label="Settings" />
          <SidebarItem icon={User} label="Account" />
        </nav>

        <div className="mt-auto pt-6 border-t border-slate-800/50">
          <div className="flex items-center gap-3 px-2 mb-6">
            <div className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center overflow-hidden">
              <img src="https://picsum.photos/seed/user/100/100" alt="Avatar" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            </div>
            <div>
              <p className="text-sm font-semibold text-slate-100">John Doe</p>
              <p className="text-[10px] text-slate-500 font-medium">Administrator</p>
            </div>
          </div>
          <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-400 hover:bg-red-500/10 transition-all duration-300">
            <LogOut size={20} />
            <span className="font-medium text-sm">Logout</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="ml-64 p-8 min-h-screen relative z-10">
        {/* Header */}
        <header className="flex items-center justify-between mb-10">
          <div>
            <h2 className="text-3xl font-bold text-white tracking-tight">Welcome back, John!</h2>
            <p className="text-slate-400 mt-1">Monitor and manage your server infrastructure.</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="relative group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-indigo-400 transition-colors" size={18} />
              <input 
                type="text" 
                placeholder="Search servers..." 
                className="bg-slate-900/50 border border-slate-800/50 rounded-2xl py-3 pl-12 pr-6 w-64 focus:outline-none focus:border-indigo-500/50 focus:ring-4 focus:ring-indigo-500/10 transition-all"
              />
            </div>
            <button className="p-3 bg-slate-900/50 border border-slate-800/50 rounded-2xl text-slate-400 hover:text-indigo-400 hover:border-indigo-500/30 transition-all relative">
              <Bell size={20} />
              <span className="absolute top-3 right-3 w-2 h-2 bg-indigo-500 rounded-full shadow-[0_0_8px_rgba(99,102,241,0.8)]" />
            </button>
          </div>
        </header>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
          <StatCard icon={Server} label="Total Servers" value="12" color="bg-indigo-500" />
          <StatCard icon={Cpu} label="CPU Usage" value="42%" color="bg-blue-500" />
          <StatCard icon={HardDrive} label="RAM Usage" value="8.4 GB" color="bg-purple-500" />
          <StatCard icon={Activity} label="Network Traffic" value="1.2 TB" color="bg-emerald-500" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Server List */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold text-white">Your Servers</h3>
              <button className="text-sm font-semibold text-indigo-400 hover:text-indigo-300 transition-colors flex items-center gap-1">
                View All <ChevronRight size={16} />
              </button>
            </div>
            
            <div className="space-y-4">
              {servers.map((server) => (
                <motion.div 
                  key={server.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  whileHover={{ scale: 1.01 }}
                  className="bg-slate-900/40 backdrop-blur-xl border border-slate-800/50 rounded-2xl p-5 flex items-center justify-between group hover:border-indigo-500/30 transition-all duration-500"
                >
                  <div className="flex items-center gap-5">
                    <div className={cn(
                      "w-12 h-12 rounded-xl flex items-center justify-center border",
                      server.status === 'online' 
                        ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" 
                        : "bg-red-500/10 border-red-500/20 text-red-400"
                    )}>
                      <Server size={24} />
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-100">{server.name}</h4>
                      <p className="text-xs text-slate-500 font-mono mt-0.5">{server.ip}</p>
                    </div>
                  </div>

                  <div className="hidden md:flex items-center gap-8">
                    <div className="text-center">
                      <p className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">CPU</p>
                      <p className="text-sm font-bold text-slate-200">{server.cpu}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">RAM</p>
                      <p className="text-sm font-bold text-slate-200">{server.ram}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">DISK</p>
                      <p className="text-sm font-bold text-slate-200">{server.disk}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button className="p-2.5 rounded-xl bg-slate-800/50 text-slate-400 hover:text-emerald-400 hover:bg-emerald-500/10 transition-all">
                      <Play size={18} />
                    </button>
                    <button className="p-2.5 rounded-xl bg-slate-800/50 text-slate-400 hover:text-indigo-400 hover:bg-indigo-500/10 transition-all">
                      <RefreshCw size={18} />
                    </button>
                    <button className="p-2.5 rounded-xl bg-slate-800/50 text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-all">
                      <Square size={18} />
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Performance Chart */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold text-white">Performance</h3>
            <div className="bg-slate-900/40 backdrop-blur-xl border border-slate-800/50 rounded-2xl p-6 h-[400px] flex flex-col">
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-indigo-500" />
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">CPU</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-purple-500" />
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">RAM</span>
                  </div>
                </div>
                <select className="bg-slate-800/50 border border-slate-700/50 rounded-lg text-xs font-bold text-slate-300 px-3 py-1.5 focus:outline-none">
                  <option>Last 24 Hours</option>
                  <option>Last 7 Days</option>
                </select>
              </div>

              <div className="flex-1 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={data}>
                    <defs>
                      <linearGradient id="colorCpu" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorRam" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#a855f7" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#a855f7" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                    <XAxis 
                      dataKey="time" 
                      stroke="#475569" 
                      fontSize={10} 
                      tickLine={false} 
                      axisLine={false} 
                    />
                    <YAxis 
                      stroke="#475569" 
                      fontSize={10} 
                      tickLine={false} 
                      axisLine={false} 
                      tickFormatter={(value) => `${value}%`}
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#0f172a', 
                        borderColor: '#1e293b', 
                        borderRadius: '12px',
                        fontSize: '12px',
                        color: '#f1f5f9'
                      }} 
                    />
                    <Area 
                      type="monotone" 
                      dataKey="cpu" 
                      stroke="#6366f1" 
                      strokeWidth={3}
                      fillOpacity={1} 
                      fill="url(#colorCpu)" 
                    />
                    <Area 
                      type="monotone" 
                      dataKey="ram" 
                      stroke="#a855f7" 
                      strokeWidth={3}
                      fillOpacity={1} 
                      fill="url(#colorRam)" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-gradient-to-br from-indigo-600 to-purple-700 rounded-2xl p-6 shadow-[0_20px_40px_rgba(79,70,229,0.2)] relative overflow-hidden group">
              <div className="absolute top-[-20%] right-[-10%] w-40 h-40 bg-white/10 rounded-full blur-3xl group-hover:scale-150 transition-transform duration-1000" />
              <h4 className="text-xl font-bold text-white mb-2 relative z-10">Need Help?</h4>
              <p className="text-indigo-100 text-sm mb-6 relative z-10">Our support team is available 24/7 to assist you with any issues.</p>
              <button className="bg-white text-indigo-600 font-bold py-3 px-6 rounded-xl hover:bg-indigo-50 transition-all relative z-10">
                Contact Support
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
